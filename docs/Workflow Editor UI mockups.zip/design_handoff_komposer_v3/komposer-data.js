// Sample content for the Komposer mockup: workflows (fuse/flow/workflows), library entries, workstream runs.
(function () {
  let UID = 1;
  const A = (mode) => (x) => ({ mode, artifact: x[0], path: x[1], description: x[2] || '' });
  const st = (id, title, instruction, o = {}) => ({ _k: UID++, id, title: title || '', phase: o.ph || '', description: o.d || '', instruction, fold: o.lit ? '|' : '>', condition: o.cond || null, consumes: o.c || [], arts: [...(o.p || []).map(A('produces')), ...(o.o || []).map(A('optional')), ...(o.u || []).map(A('updates'))], gates: o.g || [] });
  const rb = (r) => (r ? [].concat(r) : []);
  const ow = (text, r) => ({ kind: 'owner-action', text, route_back_to: rb(r), description: '' });
  const ck = (text = 'default', r) => ({ kind: 'check', text, route_back_to: rb(r), description: '' });
  const sc = (text, r) => ({ kind: 'script', text, route_back_to: rb(r), description: '' });
  const ag = (text, max_rounds = 2, guide = '', r) => ({ kind: 'agent', text, max_rounds, guide, route_back_to: rb(r), description: '' });
  const K = (s) => '.konductor/' + s;
  const CODE = [['code', '.']];
  const SCHEMA = (rel) => ['# $schema: ' + rel + 'schemas/workflow.schema.json', '# yaml-language-server: $schema=' + rel + 'schemas/workflow.schema.json'];

  const superpowers = [
    st('design', 'Design', 'Turn the owner\'s idea into an approved design. Before your first question, classify the request and say the classification, so the owner can override it. A bounded change is a well-scoped change to a flow that already exists in this repository: ask the questions that matter, present a short design in chat, and report the spec as not produced, giving "bounded change" as the reason. Anything else is architectural, including every new project: write the spec as its guide describes. A spike, a question whose answer is not code you keep, does not need this workflow; say so and let the owner decide. When in doubt, take the heavier path, and step up when hidden complexity appears. Read-only exploration is allowed; do not set up, scaffold, plan or implement anything until the owner approves the design.',
      { ph: 'Design', p: [['design-spec', 'docs/superpowers/specs/{slug}-design.md']], g: [ow('approve the design, either the written spec or the short design given in chat')] }),
    st('plan', 'Implementation plan', 'Turn the approved spec into an implementation plan for an engineer with no context, as its guide describes. Recommend an execution mode, subagent-driven or inline, and give the reason. Do not start implementing until the owner approves the plan and chooses the mode.',
      { ph: 'Design', cond: { kind: 'agent', text: 'the design step wrote a spec; a bounded change whose design was approved in chat needs no plan' }, c: ['design-spec'], p: [['implementation-plan', 'docs/superpowers/plans/{slug}.md']], g: [ow('approve the implementation plan and choose the execution mode', 'design')] }),
    st('workspace', 'Branch and baseline', 'Prepare this checkout for the work. If it is on the integration branch, create a feature branch from HEAD, named after the workstream unless the owner prefers another name, so that it carries the spec and plan commits. Never implement on the integration branch without the owner\'s explicit consent. Then run the project\'s setup, such as installing dependencies, and establish a clean test baseline. If the baseline fails, report the failures and let the owner decide whether to continue or investigate first.',
      { ph: 'Build', g: [ck()] }),
    st('implement', 'Implement', [
      'Execute the plan in the mode the owner chose, recorded in the plan\'s front matter, or implement the bounded design approved in chat. Work continuously: do not stop between tasks to check in. Decide conflicts, ambiguities and plan defects yourself, with the spec as the binding authority, and record each decision as a ruling. Stop and ask only before an irreversible or destructive operation, a security-sensitive action, a side effect outside this checkout such as a push to a shared branch, or when the plan is so broken that every way forward is a guess.',
      'Keep a progress ledger in a git-ignored file, such as .superpowers/sdd/<slug>/progress.md, with one line per completed task and one per ruling, and trust it and the git log over your memory after a context reset.',
      'In subagent-driven mode, give each task to a fresh implementer with only that task\'s text, the interfaces it touches and the global constraints, one task at a time and never in parallel. After each task, have a fresh reviewer check spec compliance and code quality against the task\'s diff, and send the required fixes back to the implementer; after five fix rounds, decide each open finding yourself and record the ruling. In inline mode, implement every task yourself.',
      'In either mode, work test-first: write the test, watch it fail for the expected reason, write the least code that makes it pass, and watch it pass. When something fails unexpectedly, find the root cause before you change code. Claim a task complete only after running its tests in this session and reading the output.',
    ].join('\n\n'), { ph: 'Build', c: ['design-spec', 'implementation-plan'], u: CODE, g: [ck(), ag('obtain a fresh review of the whole branch, from the commit it started at to HEAD', 2, 'whole-branch-review.md', 'plan')] }),
    st('finish', 'Finish the branch', 'Integrate the finished branch the way the owner chooses. Confirm the base branch the work started from, and ask when it is not certain, because merging into the wrong base is expensive to undo. Present exactly three options: merge the branch into its base locally, push it and open a pull request, or keep it as it is. Discard the work only when the owner explicitly asks for it, and only after they confirm by typing "discard". Carry out only the owner\'s choice. After a local merge, run the tests on the merged result, and delete the branch only when they pass. For a pull request, report its address. Then record the choice with --owner-approved and a note.',
      { ph: 'Finish', g: [ck(), sc('test -z "$(git status --porcelain)"'), ow('choose how to integrate the branch')] }),
  ];

  const fullSdlc = [
    st('elicitation', '0. Intake elicitation', 'Resolve the request into a requirements summary: goals, non-goals, constraints, open decisions with your recommendation. Skip the questioning when the request already answers them and say so in the summary.', { p: [['requirements-summary', K('requirements/requirements-summary.md')]] }),
    st('codebase-analysis', '1. Codebase analysis', 'Read the existing code before designing against it. Record architecture, the patterns and vocabulary the code already uses, build and test commands, and the places the request will touch, each with file and line.', { p: [['codebase-analysis', K('analysis/codebase-analysis.md')]] }),
    st('requirements', '2. Requirements', 'Write the user stories and acceptance criteria from the requirements summary and the codebase analysis, in the code\'s vocabulary.', { p: [['user-stories', K('requirements/user-stories.md')]], c: ['requirements-summary', 'codebase-analysis'], g: [ow('approve the user stories')] }),
    st('design', '3. Design', 'Write the design document. Cite code for every claim about current behaviour; mark what could not be verified.', { p: [['design', K('design/design.md')]], c: ['user-stories', 'codebase-analysis'] }),
    st('design-review', '4. Principal engineer design review', 'Review .konductor/design/design.md independently of the author. Fix every CRITICAL finding in design.md itself, never by deferring it to implementation, and record the findings and their resolution.', { p: [['design-review', K('design/design-review.md')]], c: ['design'], u: [['design', K('design/design.md')]], g: [ow('approve the reviewed design', 'design')] }),
    st('feature-splitting', '5. Feature splitting', 'Split the design into features that can be built independently, give each a unique slug, and record the split. The owner approves it.', { p: [['feature-split', K('features/feature-split.md')]], c: ['design'], g: [ow('approve the feature split')] }),
    st('specs', '6. Specs (per feature)', 'For each feature in feature-split.md write requirements.md, design.md and tasks.md under .kiro/specs/<feature>/, then list the spec directories in the index artifact.', { p: [['spec-index', K('specs/index.md')]], c: ['feature-split'], g: [ow('approve the feature specifications')] }),
    st('implementation', '7. Implementation (per feature)', 'Implement each feature from its tasks.md on its own branch, with unit and integration tests. Record the commands and their terminal output in the implementation report.', { p: [['implementation-report', K('implementation/implementation-report.md')]], c: ['spec-index'], u: CODE }),
    st('code-review', '8. Code review and pull request (per feature)', 'Commit each feature, open one pull request per feature, and review the diff. Fix CRITICAL findings on the feature branch, re-run the build and tests, and record the review. Never merge.', { p: [['code-review', K('review/code-review.md')]], u: CODE, g: [ow('approve the pull requests or pushed branches for all features at once', 'implementation')] }),
    st('testing', '9. Testing (per feature)', 'Find the coverage gaps for what was implemented, write the missing tests on the feature branch and update its pull request. Record the remaining gaps with a reason each.', { p: [['test-coverage', K('testing/test-coverage.md')]], c: ['code-review'], u: CODE, g: [ow('accept the coverage gaps that stay open', 'implementation')] }),
    st('documentation', '10. Documentation', 'Write or update the README and developer guide for what shipped, then check every claim in them against the implementation.', { p: [['doc-accuracy', K('docs/doc-accuracy.md')]] }),
    st('final-summary', '11. Final summary', 'Write the summary for a reader who did not watch the work: what was delivered, what was verified and how, and what is left for the owner.', { p: [['sdlc-summary', K('sdlc-summary.md')]], c: ['implementation-report', 'code-review', 'test-coverage', 'doc-accuracy'] }),
  ];

  const phaseChain = [
    st('pm', '1. PM', 'Write the user stories and acceptance criteria from the request, then check them against the request.', { p: [['user-stories', K('requirements/user-stories.md')]] }),
    st('architect', '2. Architect', 'Write the system design: architecture, non-functional requirements, threat model, API and data models, access policies.', { p: [['design', K('design/design.md')]], c: ['user-stories'] }),
    st('feature-splitting', '3. Feature splitting', 'Split the design into features that can be built independently and give each a unique slug.', { lit: true, p: [['feature-split', K('features/feature-split.md')]], c: ['design'] }),
    st('specs', '4. Developer (specs, per feature)', 'For each feature in feature-split.md write requirements.md, design.md and tasks.md, then list the spec directories in the index artifact.', { p: [['spec-index', K('specs/index.md')]], c: ['feature-split'] }),
    st('implementation', '5. Developer (implementation, per feature)', 'Implement each feature from its tasks.md with tests. Record the commands and their terminal output in the implementation report.', { p: [['implementation-report', K('implementation/implementation-report.md')]], c: ['spec-index'], u: CODE }),
    st('code-review', '5a. Code review (per feature)', 'Review the git diff of each feature. Fix every CRITICAL finding in the implementation, re-run the build and tests, and record the review.', { p: [['code-review', K('review/code-review.md')]], u: CODE, g: [ag('review the git diff of each feature; a CRITICAL finding fails the round', 2, '', 'implementation')] }),
    st('qa', '6. QA', 'Find the test coverage gaps, plan the end-to-end and security tests, check user-facing text, and record the findings.', { p: [['test-coverage', K('testing/test-coverage.md')]] }),
  ];

  const large = [
    st('elicitation', 'Intake elicitation', 'Resolve the request into a requirements summary.', { p: [['requirements-summary', K('requirements/requirements-summary.md')]], g: [ow('approve the requirements summary')] }),
    st('codebase-analysis', 'Codebase analysis', 'Map architecture, conventions, build and test commands.', { p: [['codebase-analysis', K('analysis/codebase-analysis.md')]], c: ['requirements-summary'] }),
    st('requirements', 'Requirements', 'Write user stories and acceptance criteria from the requirements summary.', { p: [['user-stories', K('requirements/user-stories.md')]], c: ['requirements-summary'], g: [ow('approve the user stories')] }),
    st('design', 'System design', 'Write the system design by following system-design-patterns/SKILL.md.', { p: [['design', K('design/design.md')]], c: ['codebase-analysis', 'user-stories'] }),
    st('threat-model', 'Threat model', 'STRIDE threat model for the design, with a mitigation per threat.', { p: [['threat-model', K('design/threat-model.md')]], c: ['design'] }),
    st('design-review', 'Principal engineer design review', 'First design-quality-check/SKILL.md, then design-evaluation/SKILL.md, then adversarial-design-review/SKILL.md.', { lit: true, p: [['design-review', K('design/design-review.md')]], c: ['design'], u: [['design', K('design/design.md')]] }),
    st('design-signoff', 'Design sign-off', 'Present the reviewed design and threat model together.', { p: [['design-signoff', K('design/signoff.md')]], c: ['threat-model', 'design-review'], g: [ow('approve the reviewed design and threat model')] }),
    st('feature-splitting', 'Feature splitting', 'Split the signed-off design into independently buildable features.', { p: [['feature-split', K('features/feature-split.md')]], c: ['design-signoff'], g: [ow('approve the feature split')] }),
    st('specs', 'Specs per feature', 'Per feature: requirements.md, design.md, tasks.md under .kiro/specs/<feature>/.', { p: [['spec-index', K('specs/index.md')]], c: ['feature-split'], g: [ow('approve the feature specifications')] }),
    st('implementation', 'Implementation per feature', 'Implement each approved feature, verify it, and record the commands and results.', { p: [['implementation-report', K('implementation/implementation-report.md')]], c: ['spec-index'], u: CODE, g: [ck()] }),
    st('code-review', 'Code review and pull requests', 'Review the implementation and pull requests, fix critical findings, and record the review.', { p: [['code-review', K('review/code-review.md')]], c: ['implementation-report'], u: CODE }),
    st('coverage-testing', 'Coverage testing', 'Find test coverage gaps, add missing tests where required, and record the remaining gaps.', { p: [['test-coverage', K('testing/test-coverage.md')]], c: ['implementation-report'], u: CODE }),
    st('security-testing', 'Security testing', 'Test every mitigation in the threat model; record gaps.', { p: [['security-tests', K('testing/security-tests.md')]], c: ['implementation-report', 'threat-model'] }),
    st('ui-testing', 'UI testing', 'One end-to-end pass against the deployed URL.', { c: ['implementation-report'], p: [['ui-tests', K('testing/ui-tests.md')]] }),
    st('documentation', 'Documentation', 'Check the documentation against the implementation and record every correction.', { p: [['doc-accuracy', K('docs/doc-accuracy.md')]], c: ['code-review'] }),
    st('release-readiness', 'Release readiness', 'Collect review, all three test reports and the docs into one go/no-go recommendation.', { lit: true, p: [['release-readiness', K('release/readiness.md')]], c: ['code-review', 'test-coverage', 'security-tests', 'ui-tests', 'doc-accuracy'], g: [ow('approve release readiness')] }),
    st('final-summary', 'Final summary', 'Deliverables, verification, open items, for a reader who was not there.', { p: [['sdlc-summary', K('sdlc-summary.md')]], c: ['release-readiness'] }),
  ];

  const medium = [
    st('codebase-analysis', 'Codebase analysis', 'Map the code the feature touches, with file and line.', { p: [['codebase-analysis', K('analysis/codebase-analysis.md')]] }),
    st('requirements', 'Requirements', 'Write user stories and acceptance criteria for the requested feature.', { p: [['user-stories', K('requirements/user-stories.md')]] }),
    st('design', 'Design', 'A one-to-two page design grounded in the analysis.', { p: [['design', K('design/design.md')]], c: ['codebase-analysis', 'user-stories'], g: [ow('approve the design')] }),
    st('implementation', 'Implementation', 'Implement the approved design, verify the change, and record the commands and results.', { p: [['implementation-report', K('implementation/implementation-report.md')]], c: ['design'], u: CODE, g: [ck()] }),
    st('code-review', 'Code review and pull request', 'Review the implementation and pull request, fix critical findings, and record the review.', { p: [['code-review', K('review/code-review.md')]], c: ['implementation-report'], u: CODE }),
    st('testing', 'Testing', 'Find test coverage gaps, add missing tests where required, and record the remaining gaps.', { p: [['test-coverage', K('testing/test-coverage.md')]], c: ['implementation-report'], u: CODE }),
    st('final-summary', 'Summary', 'What shipped, the pull request, what was verified, what is open.', { p: [['sdlc-summary', K('sdlc-summary.md')]], c: ['code-review', 'test-coverage'], g: [ow('approve the final summary')] }),
  ];

  const small = () => [
    st('implementation', 'Implement', 'Make the smallest change that fixes the request, with a test that fails before it and passes after. Record the command and its output.', { p: [['implementation-report', K('implementation/implementation-report.md')]], u: CODE, g: [ck()] }),
    st('code-review', 'Self review', 'Review your own diff, fix CRITICAL findings, commit.', { p: [['code-review', K('review/code-review.md')]], u: CODE }),
    st('final-summary', 'Summary', 'One paragraph for the owner, what changed, how it was verified.', { p: [['sdlc-summary', K('sdlc-summary.md')]], c: ['implementation-report', 'code-review'], g: [ow('approve the summary')] }),
  ];

  const ambiguous = [
    st('elicitation', 'Intake elicitation', 'Surface goals, assumptions and the questions only the owner can answer.', { p: [['requirements-summary', K('requirements/requirements-summary.md')]], g: [ow('approve the requirements summary')] }),
    st('prior-art', 'Prior art research', 'How others solved this, inside and outside the company.', { p: [['prior-art', K('research/prior-art.md')]], c: ['requirements-summary'] }),
    st('codebase-analysis', 'Codebase analysis', 'What the code already offers that the answer could reuse.', { p: [['codebase-analysis', K('analysis/codebase-analysis.md')]], c: ['requirements-summary'] }),
    st('option-a', 'Option A sketch', 'A one-page sketch of the simplest direction.', { p: [['option-a', K('options/option-a.md')]], c: ['prior-art', 'codebase-analysis'] }),
    st('option-b', 'Option B sketch', 'A one-page sketch of the most complete direction.', { p: [['option-b', K('options/option-b.md')]], c: ['prior-art', 'codebase-analysis'] }),
    st('spike', 'Spike', 'Throwaway prototype of the riskiest assumption shared by both options.', { p: [['spike-findings', K('options/spike-findings.md')]], c: ['codebase-analysis'] }),
    st('decision', 'Decision', 'Compare A and B with the spike findings; recommend one.', { p: [['decision', K('options/decision.md')]], c: ['option-a', 'option-b', 'spike-findings'], g: [ow('approve the decision')] }),
    st('requirements', 'Requirements', 'Write user stories and acceptance criteria for the chosen option.', { p: [['user-stories', K('requirements/user-stories.md')]], c: ['decision'], g: [ow('approve the user stories')] }),
    st('implementation', 'Implementation', 'Implement the approved requirements, verify the change, and record the commands and results.', { p: [['implementation-report', K('implementation/implementation-report.md')]], c: ['user-stories'], u: CODE, g: [ck()] }),
    st('code-review', 'Code review', 'Review the implementation, fix critical findings, and record the review.', { p: [['code-review', K('review/code-review.md')]], u: CODE }),
    st('final-summary', 'Summary', 'Which option was chosen and why, what shipped, what is open.', { p: [['sdlc-summary', K('sdlc-summary.md')]], c: ['decision', 'implementation-report', 'code-review'] }),
  ];

  const hotfix = () => [
    st('repro', 'Reproduce', 'Write a failing test that captures the reported bug. Do not change production code yet.', { ph: 'Fix', p: [['repro', K('hotfix/{slug}/repro.md')]], g: [sc('test -f .konductor/hotfix/{slug}/repro.md')] }),
    st('root-cause', 'Root cause', 'Find the root cause and record it with file and line.', { ph: 'Fix', d: 'Only for bugs that are not obvious from the failing test.', cond: { kind: 'agent', text: 'the cause is not evident from the failing test' }, c: ['repro'], p: [['root-cause', K('hotfix/{slug}/root-cause.md')]] }),
    st('fix', 'Fix', 'Make the smallest change that turns the failing test green.', { ph: 'Fix', c: ['repro', 'root-cause'], u: CODE, o: [['follow-ups', K('hotfix/{slug}/follow-ups.md')]], g: [ck(), ag('review the fix diff for regressions and missing tests', 3, '', 'fix')] }),
    st('release-note', 'Release note', 'Two sentences for the changelog: what broke, what is fixed.', { ph: 'Ship', c: ['repro'], p: [['release-note', K('hotfix/{slug}/release-note.md')]], g: [ow('approve the release note', 'fix')] }),
  ];

  const docRefresh = [
    st('docs', 'Refresh docs', 'Check README and docs/ against the code, fix every inaccuracy, record what changed.', { p: [['doc-accuracy', K('docs/{slug}/doc-accuracy.md')]], u: [['code', 'docs/']], g: [ck('docs')] }),
    st('summary', 'Summary', 'List the corrections for the owner.', { c: ['doc-accuracy'], p: [['sdlc-summary', K('{slug}/summary.md')]], g: [ow('approve the corrections')] }),
  ];

  const quickReview = [
    st('review', 'Review branch', 'Review the current branch against main. Record findings by severity.', { p: [['code-review', '.reviews/{slug}.md']], g: [ag('obtain a second opinion on the findings', 1, 'second-opinion.md')] }),
    st('fixes', 'Apply fixes', 'Fix the CRITICAL and MAJOR findings, re-run the tests.', { c: ['code-review'], u: CODE, g: [ck(), ow('accept the remaining findings', 'review')] }),
  ];

  const W = (loc, dir, file, name, description, steps, o = {}) => ({ loc, dir, file, name, description, steps, head: o.head || [], blank: !!o.blank });
  const workflows = [
    W('project', '', 'hotfix', 'hotfix', 'Reproduce, fix and verify a production bug, then write the release note.', hotfix(), { head: SCHEMA('../../fuse-flow/workflows/') }),
    W('project', 'docs/', 'doc-refresh', 'doc-refresh', 'Bring the docs back in line with the code.', docRefresh),
    W('personal', '', 'quick-review', 'quick-review', 'Review a branch with a second opinion, then fix.', quickReview),
    W('fuse-flow', '', '_k-full-sdlc', 'k-full-sdlc', 'Port of the former k-full-sdlc SOP, requirements through documentation for one feature or project, with its steps 0 to 11 in the same order.', fullSdlc, { head: [...SCHEMA('./'), '# above comments enable live schema validation in WebStorm and vscode', '', '# SPDX-License-Identifier: Apache-2.0'] }),
    W('fuse-flow', '', '_k-phase-chain', 'k-phase-chain', 'Konductor\'s lighter six-phase chain, PM through QA, with no owner gates.', phaseChain, { head: [...SCHEMA('./'), '', '# SPDX-License-Identifier: Apache-2.0'] }),
    W('fuse-flow', 'examples/', 'custom-example-ambiguous', 'custom-example-ambiguous', 'Unclear request; discover and decide first, then build lean.', ambiguous, { head: [...SCHEMA('../'), '# SPDX-License-Identifier: Apache-2.0'] }),
    W('fuse-flow', 'examples/', 'custom-example-large', 'custom-example-large', 'Multi-feature project, heavy review, security and release gates.', large, { head: [...SCHEMA('../'), '# SPDX-License-Identifier: Apache-2.0'] }),
    W('fuse-flow', 'examples/', 'custom-example-medium', 'custom-example-medium', 'One feature, known codebase, one design checkpoint.', medium, { head: [...SCHEMA('../'), '# SPDX-License-Identifier: Apache-2.0'] }),
    W('fuse-flow', 'examples/', 'custom-example-small', 'custom-example-small', 'Lightweight loop for a small, well-understood change.', small(), { head: [...SCHEMA('../'), '# SPDX-License-Identifier: Apache-2.0'] }),
    W('fuse-flow', 'examples/superpowers/', 'superpowers', 'superpowers', 'Spec-driven development after obra/superpowers. Design with the owner, plan for an implementer without context, build test-first with independent review, and let the owner decide how the branch is integrated.', superpowers, { blank: true, head: [...SCHEMA('../../'), '# above comments enable live schema validation in WebStorm and vscode', '#', '# Start a workstream with:  fuse-flow start <slug> --workflow superpowers'] }),
  ];

  // Seeded working copies: hotfix has an unsaved reorder that breaks a reference; small changed on disk while open.
  const hot = workflows[0];
  hot.edit = (w) => { const [rc] = w.steps.splice(1, 1); w.steps.splice(2, 0, rc); };
  const sm = workflows.find((w) => w.file === 'custom-example-small');
  sm.edit = (w) => { w.steps[1].title = 'Self-review'; };
  sm.diskEdit = (w) => { w.steps[1].instruction = 'Review your own diff against the base branch, fix CRITICAL findings, commit.'; w.steps[1].gates.push(ck()); };
  sm.diskAt = '14:31';

  // Library: [id, level, files, purpose, sections]
  const LIB = [
    ['code', 'fuse-flow', 'g', 'Changes to the repository itself: source, tests and configuration.', ['Scope of the change', 'Tests', 'Commits']],
    ['design', 'fuse-flow', 'gr', 'The system design for the change.', ['Context', 'Architecture', 'Data model', 'Risks']],
    ['design', 'project', 'gt', 'The system design, in this project\'s ADR-like format.', ['Context', 'Decision', 'Consequences', 'Rollout']],
    ['design-spec', 'fuse-flow', 'gt', 'A design spec an implementer without context can build from.', ['Problem', 'Goals and non-goals', 'Design', 'Alternatives considered', 'Open questions']],
    ['doc-accuracy', 'fuse-flow', 'g', 'Every documentation claim checked against the implementation.', ['Documents checked', 'Corrections', 'Unverifiable claims']],
    ['feature-split', 'fuse-flow', 'gt', 'Features that can be built independently, each with a slug.', ['Features', 'Dependencies', 'Order']],
    ['implementation-plan', 'fuse-flow', 'gt', 'Bite-sized tasks for an engineer with no context, with exact files and commands.', ['Execution mode', 'Global constraints', 'Tasks', 'Verification']],
    ['requirements-summary', 'fuse-flow', 'gt', 'Goals, non-goals, constraints and open decisions.', ['Goals', 'Non-goals', 'Constraints', 'Open decisions']],
    ['spec-index', 'fuse-flow', 'g', 'The list of spec directories, one per feature.', ['Specs']],
    ['task-doc', 'fuse-flow', 'gt', 'One task with its context and acceptance check.', ['Context', 'Task', 'Acceptance']],
    ['test-coverage', 'fuse-flow', 'g', 'Coverage gaps found, tests added, gaps left open with reasons.', ['Gaps found', 'Tests added', 'Open gaps']],
    ['user-stories', 'fuse-flow', 'gtr', 'User stories with testable acceptance criteria.', ['Stories', 'Acceptance criteria', 'Owner decisions']],
    ['code-review', 'project', 'gr', 'Review findings by severity, with their resolution.', ['Findings', 'Resolution', 'Re-run results']],
    ['threat-model', 'personal', 'gr', 'STRIDE threats for the design, with a mitigation per threat.', ['Assets', 'Threats', 'Mitigations']],
  ];

  // Runs: workstreams found in the project. Events: [time 'MM-DD HH:MM', step, from, to, actor, detail, backFrom]
  const RUNS = [
    { id: 'auth-refresh', wf: 'fuse-flow:examples/superpowers/superpowers', now: '10-04 14:20', events: [
      ['10-02 09:02', 'design', 'not_started', 'in_progress', 'agent', 'Classified as architectural.'],
      ['10-02 09:48', 'design', 'in_progress', 'waiting', 'agent', 'Recorded design-spec: docs/superpowers/specs/auth-refresh-design.md'],
      ['10-02 10:31', 'design', 'waiting', 'completed', 'owner', 'Approved. Keep refresh tokens out of local storage.'],
      ['10-02 10:32', 'plan', 'not_started', 'in_progress', 'agent', 'Condition (agent): applies, the design step wrote a spec.'],
      ['10-02 11:20', 'plan', 'in_progress', 'waiting', 'agent', 'Recorded implementation-plan. Recommends subagent-driven mode.'],
      ['10-02 13:05', 'plan', 'waiting', 'completed', 'owner', 'Mode: subagent-driven.'],
      ['10-02 13:06', 'workspace', 'not_started', 'in_progress', 'agent', 'Branch auth-refresh from main@4c1e9a2.'],
      ['10-02 13:14', 'workspace', 'in_progress', 'completed', 'agent', 'check default: passed, 412 tests.'],
      ['10-02 13:15', 'implement', 'not_started', 'in_progress', 'agent', '12 tasks from the plan.'],
      ['10-03 10:40', 'implement', 'in_progress', 'in_progress', 'agent', 'check default: passed, 438 tests.'],
      ['10-03 11:02', 'implement', 'in_progress', 'in_progress', 'agent', 'agent review, round 1 of 2: 3 findings, 1 critical. Fixed.'],
      ['10-03 11:47', 'implement', 'in_progress', 'waiting', 'agent', 'agent review, round 2 of 2: 1 critical finding open.'],
      ['10-03 15:10', 'implement', 'waiting', 'not_started', 'owner', 'Sent back to plan: no task covers token rotation.'],
      ['10-03 15:10', 'plan', 'completed', 'in_progress', 'owner', 'Sent back from implement.', 'implement'],
      ['10-03 15:52', 'plan', 'in_progress', 'waiting', 'agent', 'Added tasks 13 and 14 for token rotation.'],
      ['10-03 16:30', 'plan', 'waiting', 'completed', 'owner', 'Approved.'],
      ['10-03 16:31', 'implement', 'not_started', 'in_progress', 'agent', 'Resuming at task 13.'],
    ] },
    { id: 'rate-limit', wf: 'fuse-flow:examples/superpowers/superpowers', now: '10-04 14:20', events: [
      ['09-28 14:00', 'design', 'not_started', 'in_progress', 'agent', 'Classified as bounded change.'],
      ['09-28 14:25', 'design', 'in_progress', 'waiting', 'agent', 'design-spec not produced: bounded change. Short design given in chat.'],
      ['09-28 14:40', 'design', 'waiting', 'completed', 'owner', 'Approved in chat.'],
      ['09-28 14:40', 'plan', 'not_started', 'skipped', 'agent', 'Condition (agent): does not apply, bounded change approved in chat.'],
      ['09-28 14:41', 'workspace', 'not_started', 'in_progress', 'agent', 'Branch rate-limit from main@91ab03e.'],
      ['09-28 14:47', 'workspace', 'in_progress', 'completed', 'agent', 'check default: passed.'],
      ['09-28 14:48', 'implement', 'not_started', 'in_progress', 'agent', 'Inline mode.'],
      ['09-28 16:20', 'implement', 'in_progress', 'completed', 'agent', 'check default: passed. agent review, round 1 of 2: no findings.'],
      ['09-28 16:21', 'finish', 'not_started', 'in_progress', 'agent', 'check default: passed. script: passed.'],
      ['09-28 16:22', 'finish', 'in_progress', 'waiting', 'agent', 'Presented merge, pull request, keep.'],
      ['09-29 09:05', 'finish', 'waiting', 'completed', 'owner', 'Pull request #214.'],
    ] },
    { id: 'login-500', wf: 'project:hotfix', now: '10-04 14:20', events: [
      ['10-04 08:10', 'repro', 'not_started', 'in_progress', 'agent', ''],
      ['10-04 08:32', 'repro', 'in_progress', 'completed', 'agent', 'script: passed.'],
      ['10-04 08:32', 'root-cause', 'not_started', 'skipped', 'agent', 'Condition (agent): does not apply, null session on an expired cookie.'],
      ['10-04 08:33', 'fix', 'not_started', 'in_progress', 'agent', ''],
      ['10-04 09:05', 'fix', 'in_progress', 'completed', 'agent', 'check default: passed. agent review, round 1 of 3: no findings.'],
      ['10-04 09:06', 'release-note', 'not_started', 'in_progress', 'agent', ''],
      ['10-04 09:10', 'release-note', 'in_progress', 'waiting', 'agent', 'Recorded release-note.'],
    ] },
    { id: 'cache-stampede', wf: 'project:hotfix', now: '10-04 14:20', events: [
      ['10-03 16:00', 'repro', 'not_started', 'in_progress', 'agent', ''],
      ['10-03 16:41', 'repro', 'in_progress', 'completed', 'agent', 'script: passed.'],
      ['10-03 16:42', 'root-cause', 'not_started', 'in_progress', 'agent', 'Condition (agent): applies, fails only under concurrent load.'],
      ['10-03 17:30', 'root-cause', 'in_progress', 'completed', 'agent', 'Lock released before the cache write.'],
      ['10-03 17:31', 'fix', 'not_started', 'in_progress', 'agent', ''],
      ['10-03 18:02', 'fix', 'in_progress', 'blocked', 'agent', 'check default: failed, 2 tests in cache.spec.ts.'],
    ] },
  ];

  window.KOMPOSER_DATA = { workflows, LIB, RUNS, newStep: (id) => st(id, '', ''), nextUid: () => UID++ };
})();
