# On Coding — Design System

**On Coding** is the blog and brand of **TotalSurpriseException (TSE)**, a YouTube channel and writing project about *career as a software developer — and everything beyond*. The audience is people teaching themselves to program and navigating the early stages of a developer career: career-switchers, beginners, and juniors looking for honest, practical guidance.

This design system is a **modern, sharp-technical editorial refresh** of the original blog (a minimalist 2019 black-on-white WordPress theme). It keeps the spirit — restraint, readability, the blue logo as the single accent — and rebuilds it as a confident developer-publication identity with a full token system, light + dark themes, reusable components, and a blog UI kit.

## Sources
- **Original blog:** https://blog.oncoding.de/ — minimalist WordPress theme, black on white, blue-to-white gradient logo as the only accent. (Read for content + voice; not directly accessible to readers of this doc.)
- **Logo:** `uploads/cropped-tse-logo.png` → copied to `assets/logo-tse-mark.png` — the TSE circuit-board gradient mark.
- **Brand:** "TotalSurpriseException" YouTube channel (German beginner programming classes + career content).

---

## CONTENT FUNDAMENTALS

**Voice:** A warm, direct mentor who has been there. Speaks *to you*, second person, like a more-experienced friend giving real advice over coffee — not a corporation, not a guru.

- **Person:** Second person "you" for the reader; first person "I"/"my" for the author's own experience and recommendations ("my beginners class on YouTube"). "We" is rare.
- **Tone:** Encouraging *and* honest. It motivates ("congratulations! … time is on your side now") but doesn't sugar-coat hard truths ("most people cannot become software developers"). Energetic, never hype-y.
- **Openings & sign-offs:** Friendly bookends — "Hey friends!" to open, "Best wishes, and good luck!" to close.
- **Structure:** Short paragraphs. Clear milestone/step framing ("The two milestones…", "…and how to get there"). Bold the pivotal idea. Practical, numbered or staged advice over theory.
- **Casing:** Sentence case everywhere in prose and headings. UPPERCASE is reserved for mono kickers/labels only (e.g. `// CAREER · 6 MIN READ`).
- **Punctuation:** Em-dashes for asides, the occasional direct rhetorical question. Contractions throughout ("you're", "don't", "it's") — it should read like speech.
- **Emoji:** None. The brand is technical and grown-up; personality comes from voice and the blue accent, not emoji.
- **Vibe:** *Sharp, practical, in-your-corner.* Sample line: "All you need is a foot in the door — build one project you're proud to talk about, then go apply."

**Do:** be specific and actionable; respect the reader's time and intelligence; lead with the real-world payoff.
**Don't:** corporate jargon, growth-hacking hype, hedging, or talking down to beginners.

---

## VISUAL FOUNDATIONS

The system reads as a **developer publication**: clean editorial structure, a cool neutral palette, the electric-blue logo gradient as the one signature move, and monospace used as a deliberate "engineered" accent.

- **Color:** A near-monochrome cool-gray foundation (ink `--text-strong` #141a23 on `--paper` white) with a single brand hue — the **blue from the TSE mark**, ramped 50→900 and crystallized into `--brand-gradient` (135°, cyan `#2bb8ea` → deep blue `#0c5398`). The gradient is the hero accent: hero word-fill, primary buttons, the newsletter band, top accent bars, progress bar. Flat `--accent` (#0a86d8) for links and small UI. Semantic green/amber/red exist but are used sparingly. **One accent hue — keep it that way.**
- **Themes:** Light is default; dark (`[data-theme="dark"]`) swaps paper to near-black `#0b0e14` with `#11161f` surfaces and shifts the accent brighter (blue-400/300) so the gradient still sings on dark.
- **Type:** Three families, each with a job. **Space Grotesk** (display) — bold, tight tracking, slightly mechanical, for headlines and hero. **IBM Plex Sans** (body/UI) — engineered, highly readable, line-height 1.7–1.8, prose measure ≤ 68ch. **JetBrains Mono** (mono) — code blocks, kickers, meta, category labels; uppercase + 0.12em tracking for kickers. Type scale is a 1.25 major third, 11→76px.
- **Spacing & layout:** 4px base grid (`--space-*`). Content container 1180px; article prose column ~720px. Generous vertical rhythm; sections separated by hairline `--border` rules and `--surface-subtle` bands rather than heavy boxes.
- **Backgrounds:** Mostly flat paper. Texture comes from *structure* — subtle subtle-gray section bands, hairline rules, the occasional full-bleed gradient panel (newsletter). No photographic hero imagery, no noise/grain, no repeating patterns. The blue gradient is the only "rich" surface and is used once or twice per page, not everywhere.
- **Corner radii:** Restrained and technical — `--radius-md` 8px for controls/cards-ish elements, `--radius-lg` 12px for cards, `--radius-xl` 18px for the big gradient panel, `--radius-pill` for chips/filters/toggles. Nothing overly soft.
- **Cards:** White `--surface` on a 1px `--border`, `--radius-lg`, very light `--shadow-xs` at rest. Hover lifts ~2–3px to `--shadow-md`, border darkens to `--border-strong`, and meta arrows nudge right. Optional 3px gradient top accent bar.
- **Shadows:** Soft, cool-tinted, low-spread (`--shadow-xs/sm/md/lg`). Deliberately subtle in light; deeper and darker in dark theme. `--shadow-brand` (blue glow) only on primary gradient buttons.
- **Borders:** Hairline 1px `--border` is the primary separator throughout — this is a line-driven, not shadow-driven, system.
- **Motion:** Quick and snappy, **no bounce.** `--ease-out` (cubic-bezier .22,1,.36,1), durations 120/180/280ms. Cards lift on hover; buttons press down ~1px and scale to .985 on active; reading progress bar fills linearly. Transitions are felt, not flashy.
- **Hover states:** Surfaces lift + shadow + border-darken; ghost buttons gain a `--surface-subtle` fill; secondary buttons shift text/border to accent; links go `--accent-hover`. **Press:** translateY(1px) + slight scale-down on buttons.
- **Transparency & blur:** Used once — the sticky header is a translucent `color-mix` paper with `backdrop-filter: blur`. Otherwise surfaces are opaque.
- **Focus:** 3px `--ring` (accent at ~45% alpha) box-shadow on focus-visible. Always visible, never removed.
- **Imagery vibe:** When imagery is added it should be cool-toned and technical (screenshots, diagrams, code) — never stock-warm lifestyle photos. The current system ships logo + UI only; flag if real imagery is needed.

---

## ICONOGRAPHY

- **Approach:** Line icons, **Lucide-style** — 1.75px stroke, `currentColor`, round caps/joins, 24px grid. Minimal and functional; icons support text, they don't decorate.
- **Where they live:** A small inline-SVG set is defined in `ui_kits/blog/data.js` (`window.OCIcons`: Search, Arrow, Youtube, Github, Clock, Share, Bookmark, Menu). They inherit `color`, so they theme automatically.
- **Substitution flag:** These are **hand-matched Lucide-equivalents**, not the official Lucide package. For production, swap in [Lucide](https://lucide.dev) (CDN or `lucide-react`) at the same 1.75 stroke weight — the look is identical. *(Flagged: no icon set was present in the source material.)*
- **Emoji:** Not used anywhere in the brand.
- **Unicode glyphs:** A few are used as lightweight UI affordances where an SVG would be overkill — `→` (card/CTA arrows), `☀`/`☾` (theme toggle), `·` (meta separators), `⌕`/`⤴`/`☆`/`▶` in specimen cards. Prefer the SVG set for anything shipping to production.
- **Logo:** `assets/logo-tse-mark.png` — the circuit-gradient disc. Pair with the "On Coding" wordmark in Space Grotesk 700. Works on light and dark; give it clear space ≈ its own corner radius.

---

## INDEX — what's in this system

**Root**
- `styles.css` — the single entry point consumers link. `@import`s only.
- `readme.md` — this file.
- `SKILL.md` — Agent-Skill manifest for use in Claude Code.

**`tokens/`** (all imported by `styles.css`)
- `fonts.css` — webfont loading (Google Fonts CDN — see Caveats).
- `colors.css` — blue scale, neutral ramp, semantic accents, light + dark semantic aliases.
- `typography.css` — families, scale, weights, line-heights, tracking, roles.
- `spacing.css` — 4px space scale, measures, container, control sizes.
- `effects.css` — radii, borders, shadows, focus ring, motion (easing/durations).
- `base.css` — element defaults + helpers (`.oc-kicker`, `.oc-gradient-text`).

**`components/`** (React primitives — namespace `window.OnCodingDesignSystem_852ae6`)
- `actions/` — **Button**, **IconButton**, **ThemeToggle**
- `data-display/` — **Tag**, **Badge**, **Avatar**
- `content/` — **Card**, **ArticleCard**
- `forms/` — **Input**
- Each has `.jsx` + `.d.ts` + `.prompt.md`; one `@dsCard` HTML per directory.

**`ui_kits/blog/`** — interactive blog recreation
- `index.html` — homepage + article reading view, with working navigation and a live light/dark toggle.
- `Header.jsx`, `HomePage.jsx`, `ArticlePage.jsx`, `Footer.jsx`, `App.jsx`, `data.js`.

**`guidelines/`** — foundation specimen cards (Design System tab): Colors (brand / neutral / semantic / surfaces), Type (display / body / mono / scale), Spacing (scale / radii & elevation), Brand (logo / voice & tone).

**`assets/`** — `logo-tse-mark.png`.

---

## CAVEATS
- **Fonts are CDN-linked, not bundled.** Space Grotesk, IBM Plex Sans and JetBrains Mono load from Google Fonts via `@import` in `tokens/fonts.css` (no binaries available to embed). They are *recommendations* matching the sharp-technical direction — the original blog used a plain system/sans theme, so there is no "official" brand font to honor. **If you have, or want, specific brand fonts, send the files and I'll self-host them.**
- **Icons are hand-matched Lucide-equivalents**, not the official package (none existed in the source). Swap to Lucide for production.
- **Direction was chosen, not dictated.** You asked to explore a range; this system commits to the *modern sharp-technical editorial* end. The other directions (refined-classic, bold-dark-creative) are not built — say the word and I'll spin up variants.
