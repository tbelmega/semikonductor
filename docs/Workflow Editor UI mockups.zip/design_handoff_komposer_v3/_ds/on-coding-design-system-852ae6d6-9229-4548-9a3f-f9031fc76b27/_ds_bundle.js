/* @ds-bundle: {"format":4,"namespace":"OnCodingDesignSystem_852ae6","components":[{"name":"Button","sourcePath":"components/actions/Button.jsx"},{"name":"IconButton","sourcePath":"components/actions/IconButton.jsx"},{"name":"ThemeToggle","sourcePath":"components/actions/ThemeToggle.jsx"},{"name":"ArticleCard","sourcePath":"components/content/ArticleCard.jsx"},{"name":"Card","sourcePath":"components/content/Card.jsx"},{"name":"Avatar","sourcePath":"components/data-display/Avatar.jsx"},{"name":"Badge","sourcePath":"components/data-display/Badge.jsx"},{"name":"Tag","sourcePath":"components/data-display/Tag.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"}],"sourceHashes":{"components/actions/Button.jsx":"519eabc60004","components/actions/IconButton.jsx":"7908bbeaef70","components/actions/ThemeToggle.jsx":"ccc2128bc218","components/content/ArticleCard.jsx":"b9f128027d46","components/content/Card.jsx":"899a3e27c0db","components/data-display/Avatar.jsx":"9e9859941b51","components/data-display/Badge.jsx":"409f2139deab","components/data-display/Tag.jsx":"c8429289381a","components/forms/Input.jsx":"36a54603a662","ui_kits/blog/App.jsx":"fc4159447384","ui_kits/blog/ArticlePage.jsx":"6284ffe58e02","ui_kits/blog/Footer.jsx":"32b03891e04d","ui_kits/blog/Header.jsx":"c18a7161641e","ui_kits/blog/HomePage.jsx":"3d43805c8574","ui_kits/blog/data.js":"65be238aef6e"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.OnCodingDesignSystem_852ae6 = window.OnCodingDesignSystem_852ae6 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/actions/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * On Coding — Button
 * Primary action uses the brand gradient; secondary is an outlined surface;
 * ghost is text-only. Sharp radii, snappy press.
 */
function Button({
  children,
  variant = 'primary',
  size = 'md',
  iconLeft = null,
  iconRight = null,
  fullWidth = false,
  disabled = false,
  type = 'button',
  onClick,
  style = {},
  ...rest
}) {
  const sizes = {
    sm: {
      height: 'var(--control-sm)',
      padding: '0 14px',
      font: 'var(--text-sm)',
      gap: '7px'
    },
    md: {
      height: 'var(--control-md)',
      padding: '0 20px',
      font: 'var(--text-sm)',
      gap: '8px'
    },
    lg: {
      height: 'var(--control-lg)',
      padding: '0 28px',
      font: 'var(--text-md)',
      gap: '10px'
    }
  };
  const s = sizes[size] || sizes.md;
  const base = {
    display: fullWidth ? 'flex' : 'inline-flex',
    width: fullWidth ? '100%' : 'auto',
    alignItems: 'center',
    justifyContent: 'center',
    gap: s.gap,
    height: s.height,
    padding: s.padding,
    fontFamily: 'var(--font-sans)',
    fontSize: s.font,
    fontWeight: 'var(--weight-semibold)',
    lineHeight: 1,
    letterSpacing: 'var(--tracking-snug)',
    borderRadius: 'var(--radius-md)',
    border: '1px solid transparent',
    cursor: disabled ? 'not-allowed' : 'pointer',
    opacity: disabled ? 0.5 : 1,
    transition: 'transform var(--duration-fast) var(--ease-out), background var(--duration-base) var(--ease-out), border-color var(--duration-base) var(--ease-out), box-shadow var(--duration-base) var(--ease-out)',
    whiteSpace: 'nowrap',
    userSelect: 'none'
  };
  const variants = {
    primary: {
      background: 'var(--brand-gradient)',
      color: 'var(--text-on-brand)',
      boxShadow: 'var(--shadow-brand)'
    },
    secondary: {
      background: 'var(--surface)',
      color: 'var(--text-strong)',
      borderColor: 'var(--border-strong)',
      boxShadow: 'var(--shadow-xs)'
    },
    ghost: {
      background: 'transparent',
      color: 'var(--text-body)'
    },
    accent: {
      background: 'var(--accent)',
      color: 'var(--text-on-brand)'
    },
    danger: {
      background: 'var(--danger)',
      color: '#fff'
    }
  };
  const [hover, setHover] = React.useState(false);
  const [active, setActive] = React.useState(false);
  const hoverStyle = !disabled && hover ? {
    primary: {
      filter: 'brightness(1.06)'
    },
    secondary: {
      borderColor: 'var(--accent)',
      color: 'var(--accent-text)'
    },
    ghost: {
      background: 'var(--surface-subtle)'
    },
    accent: {
      background: 'var(--accent-hover)'
    },
    danger: {
      filter: 'brightness(1.06)'
    }
  }[variant] : {};
  return /*#__PURE__*/React.createElement("button", _extends({
    type: type,
    disabled: disabled,
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => {
      setHover(false);
      setActive(false);
    },
    onMouseDown: () => setActive(true),
    onMouseUp: () => setActive(false),
    style: {
      ...base,
      ...variants[variant],
      ...hoverStyle,
      transform: !disabled && active ? 'translateY(1px) scale(0.985)' : 'none',
      ...style
    }
  }, rest), iconLeft, children, iconRight);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/actions/Button.jsx", error: String((e && e.message) || e) }); }

// components/actions/IconButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * On Coding — IconButton
 * Square, icon-only control for toolbars, cards and nav (e.g. theme toggle, share).
 */
function IconButton({
  children,
  label,
  variant = 'ghost',
  size = 'md',
  disabled = false,
  onClick,
  style = {},
  ...rest
}) {
  const dims = {
    sm: 32,
    md: 40,
    lg: 48
  };
  const d = dims[size] || dims.md;
  const variants = {
    ghost: {
      background: 'transparent',
      color: 'var(--text-muted)',
      border: '1px solid transparent'
    },
    outline: {
      background: 'var(--surface)',
      color: 'var(--text-body)',
      border: '1px solid var(--border-strong)'
    },
    solid: {
      background: 'var(--accent)',
      color: '#fff',
      border: '1px solid transparent'
    }
  };
  const [hover, setHover] = React.useState(false);
  const hoverStyle = !disabled && hover ? {
    ghost: {
      background: 'var(--surface-subtle)',
      color: 'var(--text-strong)'
    },
    outline: {
      borderColor: 'var(--accent)',
      color: 'var(--accent-text)'
    },
    solid: {
      background: 'var(--accent-hover)'
    }
  }[variant] : {};
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    "aria-label": label,
    title: label,
    disabled: disabled,
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      width: d,
      height: d,
      borderRadius: 'var(--radius-md)',
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.5 : 1,
      transition: 'var(--transition)',
      ...variants[variant],
      ...hoverStyle,
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/actions/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/actions/ThemeToggle.jsx
try { (() => {
/**
 * On Coding — ThemeToggle
 * Segmented light/dark switch. Sets data-theme on the chosen target
 * (defaults to <html>) and reports the value via onChange.
 */
function ThemeToggle({
  value,
  defaultValue = 'light',
  onChange,
  target,
  style = {}
}) {
  const [internal, setInternal] = React.useState(defaultValue);
  const theme = value ?? internal;
  const apply = next => {
    if (value === undefined) setInternal(next);
    const el = target || (typeof document !== 'undefined' ? document.documentElement : null);
    if (el) el.setAttribute('data-theme', next);
    onChange && onChange(next);
  };
  const opts = [{
    key: 'light',
    label: '☀'
  }, {
    key: 'dark',
    label: '☾'
  }];
  return /*#__PURE__*/React.createElement("div", {
    role: "group",
    "aria-label": "Theme",
    style: {
      display: 'inline-flex',
      padding: 3,
      gap: 2,
      background: 'var(--surface-subtle)',
      border: '1px solid var(--border)',
      borderRadius: 'var(--radius-pill)',
      ...style
    }
  }, opts.map(o => {
    const on = theme === o.key;
    return /*#__PURE__*/React.createElement("button", {
      key: o.key,
      type: "button",
      "aria-pressed": on,
      "aria-label": o.key,
      onClick: () => apply(o.key),
      style: {
        display: 'inline-flex',
        alignItems: 'center',
        justifyContent: 'center',
        width: 30,
        height: 30,
        border: 'none',
        cursor: 'pointer',
        borderRadius: 'var(--radius-pill)',
        fontSize: 14,
        lineHeight: 1,
        background: on ? 'var(--surface)' : 'transparent',
        color: on ? 'var(--accent-text)' : 'var(--text-faint)',
        boxShadow: on ? 'var(--shadow-xs)' : 'none',
        transition: 'var(--transition)'
      }
    }, o.label);
  }));
}
Object.assign(__ds_scope, { ThemeToggle });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/actions/ThemeToggle.jsx", error: String((e && e.message) || e) }); }

// components/content/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * On Coding — Card
 * Generic surface container. Flat by default; `hoverable` lifts on hover.
 */
function Card({
  children,
  padding = 'md',
  hoverable = false,
  accent = false,
  as = 'div',
  style = {},
  ...rest
}) {
  const pads = {
    none: 0,
    sm: 'var(--space-4)',
    md: 'var(--space-5)',
    lg: 'var(--space-6)'
  };
  const [hover, setHover] = React.useState(false);
  const Comp = as;
  return /*#__PURE__*/React.createElement(Comp, _extends({
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      position: 'relative',
      background: 'var(--surface)',
      border: '1px solid var(--border)',
      borderRadius: 'var(--radius-lg)',
      padding: pads[padding] ?? pads.md,
      boxShadow: hoverable && hover ? 'var(--shadow-md)' : 'var(--shadow-xs)',
      transform: hoverable && hover ? 'translateY(-2px)' : 'none',
      borderColor: hoverable && hover ? 'var(--border-strong)' : 'var(--border)',
      transition: 'var(--transition)',
      overflow: 'hidden',
      ...style
    }
  }, rest), accent && /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      top: 0,
      left: 0,
      right: 0,
      height: 3,
      background: 'var(--brand-gradient)'
    }
  }), children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/content/Card.jsx", error: String((e && e.message) || e) }); }

// components/data-display/Avatar.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * On Coding — Avatar
 * Author / channel avatar. Falls back to mono initials on a brand-tinted surface.
 */
function Avatar({
  src,
  name = '',
  size = 40,
  ring = false,
  style = {},
  ...rest
}) {
  const initials = name.split(' ').filter(Boolean).slice(0, 2).map(p => p[0]).join('').toUpperCase();
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      width: size,
      height: size,
      flex: '0 0 auto',
      borderRadius: '50%',
      overflow: 'hidden',
      background: src ? 'var(--surface-subtle)' : 'var(--accent-soft)',
      color: 'var(--accent-text)',
      fontFamily: 'var(--font-mono)',
      fontSize: Math.max(11, Math.round(size * 0.36)),
      fontWeight: 'var(--weight-medium)',
      letterSpacing: '0.02em',
      boxShadow: ring ? '0 0 0 2px var(--paper), 0 0 0 4px var(--accent)' : 'none',
      ...style
    }
  }, rest), src ? /*#__PURE__*/React.createElement("img", {
    src: src,
    alt: name,
    style: {
      width: '100%',
      height: '100%',
      objectFit: 'cover'
    }
  }) : initials || '·');
}
Object.assign(__ds_scope, { Avatar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data-display/Avatar.jsx", error: String((e && e.message) || e) }); }

// components/data-display/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * On Coding — Badge
 * Small status / count indicator. Pill-shaped, denser than Tag.
 */
function Badge({
  children,
  tone = 'brand',
  dot = false,
  style = {},
  ...rest
}) {
  const tones = {
    brand: {
      bg: 'var(--accent-soft)',
      fg: 'var(--accent-text)'
    },
    neutral: {
      bg: 'var(--surface-subtle)',
      fg: 'var(--text-muted)'
    },
    success: {
      bg: 'var(--success-soft)',
      fg: 'var(--success)'
    },
    warning: {
      bg: 'var(--warning-soft)',
      fg: 'var(--warning)'
    },
    danger: {
      bg: 'var(--danger-soft)',
      fg: 'var(--danger)'
    }
  };
  const t = tones[tone] || tones.brand;
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: '6px',
      padding: '2px 9px',
      minWidth: 20,
      height: 20,
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-2xs)',
      fontWeight: 'var(--weight-semibold)',
      lineHeight: 1,
      borderRadius: 'var(--radius-pill)',
      background: t.bg,
      color: t.fg,
      ...style
    }
  }, rest), dot && /*#__PURE__*/React.createElement("span", {
    style: {
      width: 6,
      height: 6,
      borderRadius: '50%',
      background: t.fg
    }
  }), children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data-display/Badge.jsx", error: String((e && e.message) || e) }); }

// components/data-display/Tag.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * On Coding — Tag
 * Category / topic label used on article cards and post headers.
 * Mono font + uppercase for the technical, "label on a chip" feel.
 */
function Tag({
  children,
  tone = 'brand',
  size = 'md',
  solid = false,
  style = {},
  ...rest
}) {
  const tones = {
    brand: {
      soft: 'var(--accent-soft)',
      text: 'var(--accent-text)',
      strong: 'var(--accent)'
    },
    neutral: {
      soft: 'var(--surface-subtle)',
      text: 'var(--text-muted)',
      strong: 'var(--gray-700)'
    },
    success: {
      soft: 'var(--success-soft)',
      text: 'var(--success)',
      strong: 'var(--success)'
    },
    warning: {
      soft: 'var(--warning-soft)',
      text: 'var(--warning)',
      strong: 'var(--warning)'
    },
    danger: {
      soft: 'var(--danger-soft)',
      text: 'var(--danger)',
      strong: 'var(--danger)'
    }
  };
  const t = tones[tone] || tones.brand;
  const pad = size === 'sm' ? '2px 8px' : '3px 10px';
  const fs = size === 'sm' ? 'var(--text-2xs)' : 'var(--text-xs)';
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: '5px',
      padding: pad,
      fontFamily: 'var(--font-mono)',
      fontSize: fs,
      fontWeight: 'var(--weight-medium)',
      letterSpacing: 'var(--tracking-wide)',
      textTransform: 'uppercase',
      lineHeight: 1.4,
      borderRadius: 'var(--radius-sm)',
      background: solid ? t.strong : t.soft,
      color: solid ? '#fff' : t.text,
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Tag });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data-display/Tag.jsx", error: String((e && e.message) || e) }); }

// components/content/ArticleCard.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * On Coding — ArticleCard
 * The signature blog post preview: kicker tag, title, dek, and meta row.
 * `featured` renders a larger lead treatment.
 */
function ArticleCard({
  title = 'Untitled',
  excerpt = '',
  category = '',
  readingTime = '',
  date = '',
  author = '',
  href = '#',
  featured = false,
  style = {},
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("a", _extends({
    href: href,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: featured ? 'var(--space-4)' : 'var(--space-3)',
      padding: featured ? 'var(--space-6)' : 'var(--space-5)',
      background: 'var(--surface)',
      border: '1px solid',
      borderColor: hover ? 'var(--border-strong)' : 'var(--border)',
      borderRadius: 'var(--radius-lg)',
      boxShadow: hover ? 'var(--shadow-md)' : 'var(--shadow-xs)',
      transform: hover ? 'translateY(-3px)' : 'none',
      transition: 'var(--transition)',
      textDecoration: 'none',
      color: 'inherit',
      height: '100%',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-3)'
    }
  }, category && /*#__PURE__*/React.createElement(__ds_scope.Tag, {
    tone: "brand",
    size: featured ? 'md' : 'sm'
  }, category), readingTime && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-xs)',
      color: 'var(--text-faint)'
    }
  }, readingTime)), /*#__PURE__*/React.createElement("h3", {
    style: {
      margin: 0,
      fontFamily: 'var(--font-display)',
      fontWeight: 'var(--weight-bold)',
      color: 'var(--text-strong)',
      letterSpacing: 'var(--tracking-tight)',
      lineHeight: 'var(--leading-tight)',
      fontSize: featured ? 'var(--text-2xl)' : 'var(--text-lg)'
    }
  }, title), excerpt && /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      color: 'var(--text-muted)',
      fontSize: featured ? 'var(--text-md)' : 'var(--text-sm)',
      lineHeight: 'var(--leading-normal)',
      display: '-webkit-box',
      WebkitLineClamp: featured ? 3 : 2,
      WebkitBoxOrient: 'vertical',
      overflow: 'hidden'
    }
  }, excerpt), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 'auto',
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-2)',
      fontSize: 'var(--text-xs)',
      color: 'var(--text-faint)',
      fontFamily: 'var(--font-mono)'
    }
  }, author && /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-muted)'
    }
  }, author), author && date && /*#__PURE__*/React.createElement("span", {
    "aria-hidden": true
  }, "\xB7"), date && /*#__PURE__*/React.createElement("span", null, date), /*#__PURE__*/React.createElement("span", {
    style: {
      marginLeft: 'auto',
      color: hover ? 'var(--accent-text)' : 'var(--text-faint)',
      transform: hover ? 'translateX(2px)' : 'none',
      transition: 'var(--transition)',
      fontWeight: 600
    }
  }, "\u2192")));
}
Object.assign(__ds_scope, { ArticleCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/content/ArticleCard.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * On Coding — Input
 * Text/email/search field. Optional leading icon and trailing slot
 * (e.g. an inline submit button for the newsletter signup).
 */
function Input({
  type = 'text',
  placeholder = '',
  value,
  defaultValue,
  onChange,
  iconLeft = null,
  trailing = null,
  size = 'md',
  invalid = false,
  disabled = false,
  style = {},
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const heights = {
    sm: 'var(--control-sm)',
    md: 'var(--control-md)',
    lg: 'var(--control-lg)'
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-2)',
      height: heights[size] || heights.md,
      padding: '0 12px',
      background: disabled ? 'var(--surface-subtle)' : 'var(--surface)',
      border: '1px solid',
      borderColor: invalid ? 'var(--danger)' : focus ? 'var(--accent)' : 'var(--border-strong)',
      borderRadius: 'var(--radius-md)',
      boxShadow: focus ? 'var(--focus-ring)' : 'none',
      transition: 'var(--transition)',
      opacity: disabled ? 0.6 : 1,
      ...style
    }
  }, iconLeft && /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      color: 'var(--text-faint)',
      flex: '0 0 auto'
    }
  }, iconLeft), /*#__PURE__*/React.createElement("input", _extends({
    type: type,
    placeholder: placeholder,
    value: value,
    defaultValue: defaultValue,
    onChange: onChange,
    disabled: disabled,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      flex: 1,
      minWidth: 0,
      border: 'none',
      outline: 'none',
      background: 'transparent',
      color: 'var(--text-strong)',
      fontFamily: 'var(--font-sans)',
      fontSize: size === 'lg' ? 'var(--text-md)' : 'var(--text-sm)'
    }
  }, rest)), trailing && /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      flex: '0 0 auto'
    }
  }, trailing));
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// ui_kits/blog/App.jsx
try { (() => {
// On Coding blog — app shell + routing
function App() {
  const [route, setRoute] = React.useState({
    view: 'home',
    id: null
  });
  const [theme, setTheme] = React.useState('light');
  const onNav = view => {
    setRoute({
      view,
      id: null
    });
    window.scrollTo(0, 0);
  };
  const onOpen = id => {
    setRoute({
      view: 'article',
      id
    });
    window.scrollTo(0, 0);
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      minHeight: '100vh',
      display: 'flex',
      flexDirection: 'column'
    }
  }, /*#__PURE__*/React.createElement(Header, {
    onNav: onNav,
    theme: theme,
    setTheme: setTheme
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, route.view === 'home' ? /*#__PURE__*/React.createElement(HomePage, {
    onOpen: onOpen
  }) : /*#__PURE__*/React.createElement(ArticlePage, {
    id: route.id,
    onOpen: onOpen,
    onNav: onNav
  })), /*#__PURE__*/React.createElement(Footer, {
    onNav: onNav
  }));
}
ReactDOM.createRoot(document.getElementById('root')).render(/*#__PURE__*/React.createElement(App, null));
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/blog/App.jsx", error: String((e && e.message) || e) }); }

// ui_kits/blog/ArticlePage.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
// On Coding blog — article reading view
function ArticlePage({
  id,
  onOpen,
  onNav
}) {
  const {
    Tag,
    Avatar,
    Button,
    IconButton,
    ArticleCard
  } = window.OnCodingDesignSystem_852ae6;
  const I = window.OCIcons;
  const posts = window.OC_POSTS;
  const post = posts.find(p => p.id === id) || posts[0];
  const related = posts.filter(p => p.id !== post.id).slice(0, 2);
  const [progress, setProgress] = React.useState(0);
  React.useEffect(() => {
    const el = document.scrollingElement || document.documentElement;
    const onScroll = () => {
      const max = el.scrollHeight - el.clientHeight;
      setProgress(max > 0 ? Math.min(1, el.scrollTop / max) : 0);
    };
    window.addEventListener('scroll', onScroll, {
      passive: true
    });
    onScroll();
    return () => window.removeEventListener('scroll', onScroll);
  }, [id]);
  return /*#__PURE__*/React.createElement("main", null, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'sticky',
      top: 68,
      zIndex: 15,
      height: 3,
      background: 'transparent'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      height: '100%',
      width: progress * 100 + '%',
      background: 'var(--brand-gradient)',
      transition: 'width 80ms linear'
    }
  })), /*#__PURE__*/React.createElement("article", {
    style: {
      maxWidth: 720,
      margin: '0 auto',
      padding: '40px 24px 72px'
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: () => onNav('home'),
    style: {
      border: 'none',
      background: 'none',
      cursor: 'pointer',
      padding: 0,
      marginBottom: 24,
      color: 'var(--text-muted)',
      fontFamily: 'var(--font-mono)',
      fontSize: 13,
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6
    }
  }, "\u2190 All articles"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12,
      marginBottom: 16
    }
  }, /*#__PURE__*/React.createElement(Tag, {
    tone: "brand"
  }, post.category), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6,
      fontFamily: 'var(--font-mono)',
      fontSize: 12,
      color: 'var(--text-faint)'
    }
  }, /*#__PURE__*/React.createElement(I.Clock, {
    size: 14
  }), post.readingTime)), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontSize: 'clamp(32px, 5vw, 46px)',
      lineHeight: 1.08,
      letterSpacing: '-0.03em',
      margin: '0 0 20px'
    }
  }, post.title), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12,
      paddingBottom: 24,
      marginBottom: 32,
      borderBottom: '1px solid var(--border)'
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    name: "On Coding",
    src: "../../assets/logo-tse-mark.png",
    size: 42,
    ring: true
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 600,
      color: 'var(--text-strong)',
      fontSize: 14
    }
  }, post.author), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 12,
      color: 'var(--text-faint)'
    }
  }, post.date)), /*#__PURE__*/React.createElement(IconButton, {
    label: "Bookmark",
    variant: "ghost"
  }, /*#__PURE__*/React.createElement(I.Bookmark, null)), /*#__PURE__*/React.createElement(IconButton, {
    label: "Share",
    variant: "ghost"
  }, /*#__PURE__*/React.createElement(I.Share, null))), /*#__PURE__*/React.createElement("div", {
    className: "oc-prose"
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 19,
      lineHeight: 1.7,
      color: 'var(--text-body)'
    }
  }, /*#__PURE__*/React.createElement("strong", {
    style: {
      color: 'var(--text-strong)'
    }
  }, "Hey friends!"), " Given you're already a professional in a different field \u2014 can you still transition into a programming career? The hard part: unlike a student in their early twenties, you rely on an ongoing income and have very little time to spare."), /*#__PURE__*/React.createElement("p", null, "A brief warning first. The obvious path looks like signing up for an online CS bachelor's and doing classes in the evenings while you keep your job. This would be a huge mistake."), /*#__PURE__*/React.createElement("blockquote", {
    style: {
      margin: '28px 0',
      padding: '4px 0 4px 22px',
      borderLeft: '3px solid var(--accent)',
      fontFamily: 'var(--font-display)',
      fontSize: 22,
      fontWeight: 500,
      lineHeight: 1.4,
      color: 'var(--text-strong)',
      letterSpacing: '-0.01em'
    }
  }, "University is the wrong place to make you a programmer."), /*#__PURE__*/React.createElement("h2", null, "The two milestones to success"), /*#__PURE__*/React.createElement("p", null, "There are two enormous milestones on the way to your programming career. You want to hit them \u2014 or fail at them \u2014 as soon as possible, so you don't waste precious time and money on a path to nowhere."), /*#__PURE__*/React.createElement("p", null, "The ", /*#__PURE__*/React.createElement("strong", null, "first milestone"), " is reached when you know for sure that programming is for you. Or not. The ", /*#__PURE__*/React.createElement("strong", null, "second"), " is reached when you first cover your cost of living with a programming job. It needn't be the cool startup role \u2014 any entry-level, freelance or part-time gig counts."), /*#__PURE__*/React.createElement("h2", null, "\u2026and how to get there"), /*#__PURE__*/React.createElement("p", null, "Learn the basics as fast as possible, then pick one real area of software development and build something small that works:"), /*#__PURE__*/React.createElement("pre", {
    style: {
      background: 'var(--surface-sunken)',
      border: '1px solid var(--border)',
      borderRadius: 'var(--radius-md)',
      padding: '16px 18px',
      overflow: 'auto',
      fontFamily: 'var(--font-mono)',
      fontSize: 13.5,
      lineHeight: 1.7,
      color: 'var(--text-body)',
      margin: '20px 0'
    }
  }, `// the only interview question that matters
function lastProject() {
  return "What was the last thing you built?";
}`), /*#__PURE__*/React.createElement("p", null, "Don't take the requirements on job listings too seriously \u2014 there are far more open positions than applicants. If you've built something and you can clearly learn on the job, you're a hire. Go for entry-level, working-student or even internship roles. All you need is a foot in the door."), /*#__PURE__*/React.createElement("p", {
    style: {
      marginBottom: 0
    }
  }, "Best wishes, and good luck!")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8,
      marginTop: 32,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(Tag, {
    tone: "neutral"
  }, "Career"), /*#__PURE__*/React.createElement(Tag, {
    tone: "neutral"
  }, "Self-taught"), /*#__PURE__*/React.createElement(Tag, {
    tone: "neutral"
  }, "First job"))), /*#__PURE__*/React.createElement("section", {
    style: {
      borderTop: '1px solid var(--border)',
      background: 'var(--surface-subtle)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container)',
      margin: '0 auto',
      padding: '48px 24px 64px'
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontSize: 'var(--text-xl)',
      marginBottom: 18
    }
  }, "Keep reading"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))',
      gap: 20
    }
  }, related.map(p => /*#__PURE__*/React.createElement("div", {
    key: p.id,
    onClick: () => {
      onOpen(p.id);
      window.scrollTo(0, 0);
    },
    style: {
      cursor: 'pointer'
    }
  }, /*#__PURE__*/React.createElement(ArticleCard, _extends({}, p, {
    href: "#",
    onClick: e => {
      e.preventDefault();
      onOpen(p.id);
      window.scrollTo(0, 0);
    }
  }))))))));
}
window.ArticlePage = ArticlePage;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/blog/ArticlePage.jsx", error: String((e && e.message) || e) }); }

// ui_kits/blog/Footer.jsx
try { (() => {
// On Coding blog — footer
function Footer({
  onNav
}) {
  const {
    Avatar
  } = window.OnCodingDesignSystem_852ae6;
  const I = window.OCIcons;
  const cols = [{
    h: 'Read',
    items: ['Latest', 'Beginners', 'Career', 'Practice']
  }, {
    h: 'Watch',
    items: ['YouTube', 'Beginner class', 'Playlists']
  }, {
    h: 'About',
    items: ['The author', 'Newsletter', 'Contact']
  }];
  return /*#__PURE__*/React.createElement("footer", {
    style: {
      borderTop: '1px solid var(--border)',
      background: 'var(--paper)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container)',
      margin: '0 auto',
      padding: '48px 24px 40px',
      display: 'flex',
      gap: 48,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: '1 1 240px',
      minWidth: 220
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      marginBottom: 12
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/logo-tse-mark.png",
    alt: "",
    style: {
      width: 30,
      height: 30
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 700,
      fontSize: 17,
      color: 'var(--text-strong)'
    }
  }, "On Coding")), /*#__PURE__*/React.createElement("p", {
    style: {
      color: 'var(--text-muted)',
      fontSize: 14,
      maxWidth: '32ch',
      margin: '0 0 14px'
    }
  }, "Career as a software developer \u2014 and everything beyond. By TotalSurpriseException."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-muted)'
    }
  }, /*#__PURE__*/React.createElement(I.Youtube, {
    size: 20
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-muted)'
    }
  }, /*#__PURE__*/React.createElement(I.Github, {
    size: 20
  })))), cols.map(c => /*#__PURE__*/React.createElement("div", {
    key: c.h,
    style: {
      flex: '0 1 auto'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 11,
      letterSpacing: '0.12em',
      textTransform: 'uppercase',
      color: 'var(--text-faint)',
      marginBottom: 12
    }
  }, c.h), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 9
    }
  }, c.items.map(it => /*#__PURE__*/React.createElement("a", {
    key: it,
    onClick: () => onNav('home'),
    style: {
      color: 'var(--text-muted)',
      fontSize: 14,
      cursor: 'pointer'
    }
  }, it)))))), /*#__PURE__*/React.createElement("div", {
    style: {
      borderTop: '1px solid var(--border)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container)',
      margin: '0 auto',
      padding: '16px 24px',
      display: 'flex',
      justifyContent: 'space-between',
      flexWrap: 'wrap',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 12,
      color: 'var(--text-faint)'
    }
  }, "\xA9 2026 On Coding"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 12,
      color: 'var(--text-faint)'
    }
  }, "Imprint \xB7 Privacy"))));
}
window.Footer = Footer;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/blog/Footer.jsx", error: String((e && e.message) || e) }); }

// ui_kits/blog/Header.jsx
try { (() => {
// On Coding blog — site header (logo, nav, search, theme toggle)
function Header({
  onNav,
  theme,
  setTheme
}) {
  const {
    IconButton,
    ThemeToggle
  } = window.OnCodingDesignSystem_852ae6;
  const I = window.OCIcons;
  return /*#__PURE__*/React.createElement("header", {
    style: {
      position: 'sticky',
      top: 0,
      zIndex: 20,
      background: 'color-mix(in srgb, var(--paper) 82%, transparent)',
      backdropFilter: 'saturate(140%) blur(10px)',
      borderBottom: '1px solid var(--border)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container)',
      margin: '0 auto',
      padding: '0 24px',
      height: 68,
      display: 'flex',
      alignItems: 'center',
      gap: 24
    }
  }, /*#__PURE__*/React.createElement("a", {
    onClick: () => onNav('home'),
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 11,
      cursor: 'pointer',
      textDecoration: 'none'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/logo-tse-mark.png",
    alt: "",
    style: {
      width: 34,
      height: 34
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 700,
      fontSize: 19,
      letterSpacing: '-0.02em',
      color: 'var(--text-strong)'
    }
  }, "On\xA0Coding")), /*#__PURE__*/React.createElement("nav", {
    style: {
      display: 'flex',
      gap: 4,
      marginLeft: 8
    }
  }, ['Articles', 'Beginners', 'Career', 'About'].map((x, i) => /*#__PURE__*/React.createElement("a", {
    key: x,
    onClick: () => onNav('home'),
    style: {
      padding: '8px 12px',
      fontSize: 14,
      fontWeight: 500,
      cursor: 'pointer',
      color: i === 0 ? 'var(--text-strong)' : 'var(--text-muted)',
      borderRadius: 'var(--radius-sm)'
    }
  }, x))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginLeft: 'auto',
      display: 'flex',
      alignItems: 'center',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement(IconButton, {
    label: "Search",
    variant: "ghost"
  }, /*#__PURE__*/React.createElement(I.Search, null)), /*#__PURE__*/React.createElement(IconButton, {
    label: "YouTube channel",
    variant: "ghost"
  }, /*#__PURE__*/React.createElement(I.Youtube, null)), /*#__PURE__*/React.createElement(ThemeToggle, {
    value: theme,
    onChange: setTheme,
    target: document.documentElement
  }))));
}
window.Header = Header;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/blog/Header.jsx", error: String((e && e.message) || e) }); }

// ui_kits/blog/HomePage.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
// On Coding blog — homepage: hero, topic filter, post grid, newsletter
function HomePage({
  onOpen
}) {
  const {
    Tag,
    ArticleCard,
    Button,
    Input,
    Avatar
  } = window.OnCodingDesignSystem_852ae6;
  const I = window.OCIcons;
  const posts = window.OC_POSTS;
  const featured = posts[0];
  const rest = posts.slice(1);
  const [topic, setTopic] = React.useState('All');
  return /*#__PURE__*/React.createElement("main", null, /*#__PURE__*/React.createElement("section", {
    style: {
      borderBottom: '1px solid var(--border)',
      background: 'var(--surface-subtle)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container)',
      margin: '0 auto',
      padding: '64px 24px 56px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "oc-kicker",
    style: {
      marginBottom: 16
    }
  }, "// Career as a software developer & beyond"), /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: 0,
      fontSize: 'clamp(40px, 6vw, 64px)',
      lineHeight: 1.04,
      letterSpacing: '-0.03em',
      maxWidth: '16ch'
    }
  }, "Learn to code. ", /*#__PURE__*/React.createElement("span", {
    className: "oc-gradient-text"
  }, "Get the job."), " Build the career."), /*#__PURE__*/React.createElement("p", {
    style: {
      marginTop: 20,
      fontSize: 19,
      lineHeight: 1.6,
      color: 'var(--text-muted)',
      maxWidth: '52ch'
    }
  }, "Honest, practical writing for people teaching themselves to program \u2014 and everything that comes after the first paid job."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 12,
      marginTop: 28,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "lg",
    iconRight: /*#__PURE__*/React.createElement(I.Arrow, null),
    onClick: () => onOpen(featured.id)
  }, "Start reading"), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    size: "lg",
    iconLeft: /*#__PURE__*/React.createElement(I.Youtube, null)
  }, "Watch on YouTube")))), /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container)',
      margin: '0 auto',
      padding: '48px 24px 72px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'baseline',
      justifyContent: 'space-between',
      marginBottom: 18
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      margin: 0,
      fontSize: 'var(--text-xl)'
    }
  }, "Latest"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8,
      flexWrap: 'wrap'
    }
  }, ['All', ...window.OC_TOPICS].slice(0, 6).map(t => /*#__PURE__*/React.createElement("button", {
    key: t,
    onClick: () => setTopic(t),
    style: {
      border: '1px solid',
      borderColor: topic === t ? 'var(--accent)' : 'var(--border)',
      background: topic === t ? 'var(--accent-soft)' : 'var(--surface)',
      color: topic === t ? 'var(--accent-text)' : 'var(--text-muted)',
      fontFamily: 'var(--font-mono)',
      fontSize: 12,
      padding: '5px 11px',
      borderRadius: 'var(--radius-pill)',
      cursor: 'pointer'
    }
  }, t)))), /*#__PURE__*/React.createElement("div", {
    onClick: () => onOpen(featured.id),
    style: {
      cursor: 'pointer',
      marginBottom: 28
    }
  }, /*#__PURE__*/React.createElement(ArticleCard, _extends({
    featured: true
  }, featured, {
    href: "#",
    onClick: e => {
      e.preventDefault();
      onOpen(featured.id);
    }
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))',
      gap: 20
    }
  }, rest.map(p => /*#__PURE__*/React.createElement("div", {
    key: p.id,
    onClick: () => onOpen(p.id),
    style: {
      cursor: 'pointer'
    }
  }, /*#__PURE__*/React.createElement(ArticleCard, _extends({}, p, {
    href: "#",
    onClick: e => {
      e.preventDefault();
      onOpen(p.id);
    }
  }))))), /*#__PURE__*/React.createElement("section", {
    style: {
      marginTop: 56,
      padding: '40px',
      borderRadius: 'var(--radius-xl)',
      background: 'var(--brand-gradient)',
      color: '#fff',
      display: 'flex',
      gap: 32,
      alignItems: 'center',
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: '1 1 280px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 12,
      letterSpacing: '0.12em',
      textTransform: 'uppercase',
      opacity: 0.85
    }
  }, "Newsletter"), /*#__PURE__*/React.createElement("h2", {
    style: {
      color: '#fff',
      margin: '8px 0 6px',
      fontSize: 'var(--text-xl)'
    }
  }, "The next post, in your inbox"), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      opacity: 0.9,
      maxWidth: '40ch'
    }
  }, "No spam. One practical email when something new goes up.")), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: '1 1 300px',
      maxWidth: 420
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--paper)',
      padding: 6,
      borderRadius: 'var(--radius-md)'
    }
  }, /*#__PURE__*/React.createElement(Input, {
    type: "email",
    placeholder: "you@example.com",
    size: "lg",
    trailing: /*#__PURE__*/React.createElement(Button, {
      size: "md",
      variant: "primary"
    }, "Subscribe")
  }))))));
}
window.HomePage = HomePage;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/blog/HomePage.jsx", error: String((e && e.message) || e) }); }

// ui_kits/blog/data.js
try { (() => {
// On Coding blog — shared post data + tiny icon set (inline SVG, currentColor)
const OC_POSTS = [{
  id: 'switch-30s',
  category: 'Career',
  readingTime: '6 min read',
  title: 'Can you still switch to programming in your 30s?',
  excerpt: "You're a professional in another field with bills to pay. The obvious path — a five-year evening degree — is a trap. Here are the two milestones that actually matter, and how to hit them fast.",
  author: 'On Coding',
  date: 'Mar 12, 2026',
  featured: true
}, {
  id: 'golden-path',
  category: 'Beginners',
  readingTime: '8 min read',
  title: 'The golden path to programming',
  excerpt: 'How to find out — quickly and cheaply — whether programming is really for you, before you sink years into it.',
  author: 'On Coding',
  date: 'Feb 28, 2026'
}, {
  id: 'first-job',
  category: 'Career',
  readingTime: '5 min read',
  title: "Don't take job requirements too seriously",
  excerpt: "There are more open positions than applicants. You don't need every skill on the listing — you need one project and the will to learn on the job.",
  author: 'On Coding',
  date: 'Feb 10, 2026'
}, {
  id: 'one-project',
  category: 'Practice',
  readingTime: '7 min read',
  title: 'Build one project you can talk about',
  excerpt: 'A small web app, a game, a useful script. The interview question that matters most is simply: tell us about the last thing you built.',
  author: 'On Coding',
  date: 'Jan 22, 2026'
}, {
  id: 'back-to-college',
  category: 'Opinion',
  readingTime: '4 min read',
  title: 'University is the wrong place to learn to code',
  excerpt: "A CS degree helps your career later. But it won't make you a programmer — and it will eat the time you need to actually learn to build software.",
  author: 'On Coding',
  date: 'Jan 6, 2026'
}];
const OC_TOPICS = ['Career', 'Beginners', 'Practice', 'Frontend', 'Java', 'Opinion'];
window.OC_POSTS = OC_POSTS;
window.OC_TOPICS = OC_TOPICS;

// Minimal inline-SVG icons (stroke, currentColor) — Lucide-style 1.75 weight
const ocIcon = (paths, vb = 24) => props => React.createElement('svg', {
  width: props && props.size || 18,
  height: props && props.size || 18,
  viewBox: '0 0 ' + vb + ' ' + vb,
  fill: 'none',
  stroke: 'currentColor',
  strokeWidth: 1.75,
  strokeLinecap: 'round',
  strokeLinejoin: 'round',
  style: props && props.style
}, paths.map((d, i) => React.createElement('path', {
  key: i,
  d
})));
window.OCIcons = {
  Search: ocIcon(['M11 11m-7 0a7 7 0 1 0 14 0a7 7 0 1 0 -14 0', 'M21 21l-4.3 -4.3']),
  Arrow: ocIcon(['M5 12h14', 'M13 6l6 6l-6 6']),
  Menu: ocIcon(['M4 6h16', 'M4 12h16', 'M4 18h16']),
  Youtube: ocIcon(['M2.5 8.5a3 3 0 0 1 3 -3h13a3 3 0 0 1 3 3v7a3 3 0 0 1 -3 3h-13a3 3 0 0 1 -3 -3z', 'M10 9l5 3l-5 3z']),
  Github: ocIcon(['M9 19c-4.3 1.4 -4.3 -2.5 -6 -3m12 5v-3.5c0 -1 .1 -1.4 -.5 -2c2.8 -.3 5.5 -1.4 5.5 -6a4.6 4.6 0 0 0 -1.3 -3.2a4.2 4.2 0 0 0 -.1 -3.2s-1.1 -.3 -3.5 1.3a12 12 0 0 0 -6.2 0c-2.4 -1.6 -3.5 -1.3 -3.5 -1.3a4.2 4.2 0 0 0 -.1 3.2a4.6 4.6 0 0 0 -1.3 3.2c0 4.6 2.7 5.7 5.5 6c-.6 .6 -.6 1.2 -.5 2v3.5']),
  Clock: ocIcon(['M12 12m-9 0a9 9 0 1 0 18 0a9 9 0 1 0 -18 0', 'M12 7v5l3 3']),
  Share: ocIcon(['M6 12m-3 0a3 3 0 1 0 6 0a3 3 0 1 0 -6 0', 'M18 6m-3 0a3 3 0 1 0 6 0a3 3 0 1 0 -6 0', 'M18 18m-3 0a3 3 0 1 0 6 0a3 3 0 1 0 -6 0', 'M8.7 10.7l6.6 -3.4', 'M8.7 13.3l6.6 3.4']),
  Bookmark: ocIcon(['M6 4h12a1 1 0 0 1 1 1v15l-7 -4l-7 4v-15a1 1 0 0 1 1 -1z'])
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/blog/data.js", error: String((e && e.message) || e) }); }

__ds_ns.Button = __ds_scope.Button;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.ThemeToggle = __ds_scope.ThemeToggle;

__ds_ns.ArticleCard = __ds_scope.ArticleCard;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.Avatar = __ds_scope.Avatar;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Tag = __ds_scope.Tag;

__ds_ns.Input = __ds_scope.Input;

})();
