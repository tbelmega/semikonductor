# Handoff: Komposer v3 — four pages (Edit · Compare · Present · Workstreams)

## Overview
Komposer (`fuse/komposer` in `tbelmega/semikonductor`, branch `fuse`) is a local editor over fuse-flow workflow YAML files. This handoff turns the current single screen into **four pages** behind a top navigation, and gives a design to the pieces the code built ad hoc:

1. **Edit** — the current editor, with the right rail redesigned (collapsed tab strip, scope order Library → Workflow → Step, YAML folded into Workflow).
2. **Compare** — two workflows side by side, aligned by step id; the left one is editable, every difference on the right has an Apply button.
3. **Present** — the same diagram, read-only and distraction-free, with collapsible drawers on both sides and an optional second workflow side by side.
4. **Workstreams** — workstreams (formerly "runs") of the selected workflow, grouped by project, with a Summary / Diagram toggle.

Terminology change, binding everywhere in the UI: **"Run" → "Workstream"**. A workstream is an instance of a workflow. Do not use the word "run" for it in any label, tooltip, toast or empty state. ("The command runs from the repository root" in field docs is a verb and stays.)

## About the design files
The files in this bundle are **design references built in HTML** — a prototype showing intended look and behaviour, not production code. Recreate it in Komposer's existing React + TypeScript codebase (`fuse/komposer/src`), reusing its components, tokens (`src/tokens/*.css`, the same On Coding tokens) and Lucide icons.

To view: serve this folder and open `Workflow Editor v3.dc.html`. It loads `support.js` (prototype runtime), `komposer-data.js` + `komposer-data-v3.js` (sample workflows, projects, workstreams) and the token CSS under `_ds/`. Keys **1–4** switch pages. A Tweaks control `startPage` opens a given page.

## Fidelity
**High fidelity.** Layout, type, spacing, colours, states and interactions are final. Use the existing token variables (`--surface`, `--surface-subtle`, `--surface-sunken`, `--border`, `--border-strong`, `--text-strong/body/muted/faint`, `--accent`, `--accent-soft`, `--accent-text`, `--brand-gradient`, `--ring`, `--shadow-xs/sm/lg`, `--ease-out`). Semantic tints (gate kinds, workstream states, diff marks) are given below as oklch formulas with light and dark variants.

## Product rules (binding, from CLAUDE.md)
- Power-user tool. No marketing or explanatory copy. Labels, values and controls only; helper text only where it prevents an error.
- Workflows are YAML files on disk; the app is a view/edit layer. Edits autosave to a working copy; **Save…** asks: update the original, or save as a new file.
- Do not overuse icon-only buttons. Every icon button has a text label or, at minimum, a tooltip with its label. Prefer labelled icon buttons.

---

## Shared shell

### Top bar (all pages)
- Height 52px, `display:grid; grid-template-columns: minmax(0,1fr) auto minmax(0,1fr)`, gap 16, padding `0 16px`, background `--surface`, 1px `--border` bottom.
- **Left:** 22px disc with `--brand-gradient` · "Komposer" (Space Grotesk 700 15px, -0.01em) · project pill with the name of the project Komposer was started on (JetBrains Mono 500 11px, `--text-muted`, `--surface-sunken`, radius 999, padding 1px 8px, tooltip "The project Komposer was started on").
- **Center:** page switcher. Container `--surface-sunken`, radius 10, padding 3, gap 3. Buttons: height 30, padding 0 18px, radius 7, IBM Plex Sans 600 13px. Active: `--surface`, `--shadow-xs`, `--text-strong`. Inactive: transparent, `--text-muted`. Labels **Edit · Compare · Present · Workstreams**; tooltips "Edit (1)" … "Workstreams (4)". Keys 1–4 switch pages when focus is not in an input.
- **Right:** theme button, height 30, padding `0 10px 0 8px`, 1px `--border`, radius 8, Plex 500 12.5px. Shows a 15px moon + "Dark" in light theme, sun + "Light" in dark theme. Tooltip "Switch to the dark/light theme". Follows the system until chosen; choice kept in localStorage (existing `theme.ts`), applied as `data-theme` on `<html>`.

### Global selected workflow
One `currentWorkflow` state shared by all pages. Selecting a workflow in the left lane on any page selects it everywhere (Edit shows it, Compare uses it as the left side, Present shows it, Workstreams filters by it). Changing it clears the step selection.

### Left lane (Edit, Compare, Workstreams; drawer in Present)
- Width 240, `--surface`, 1px `--border` right. Search input (34px, radius 8) + **"+ New"** button (34px, padding 0 10, `--brand-gradient`, white Plex 600 13px, tooltip "New workflow").
- Location groups (Project / Personal / fuse-flow) and folders **open and close** (12px chevron rotating 0°→90°, 120ms). Group header: mono 500 11px uppercase .12em `--text-muted` + root path mono 11px `--text-faint`, ellipsis. Open state persisted (existing `useFolderState`). While searching, everything is open.
- Workflow row: name mono 500 12.5px, meta mono 11px `--text-muted`. Selected: 1px `--accent` border + `--accent-soft`.
- **Meta per page:** Edit/Compare: "N steps · M gates" (no workstream count). Workstreams: "N workstreams · M active" or "no workstreams"; rows without workstreams at 50% opacity.
- **Workstreams page only:** a top row **"All workstreams"** (Plex 600 13px, count mono 11px) that removes the workflow filter; and an extra group **"Other projects"** (root text "opened with their workstreams") listing workflows that live in other projects (read-only).
- **Compare page only:** the selected (left) row shows a tag "left" (`--accent` bg, white, mono 600 10px, pill). The right workflow's row has a dashed `--accent` border and tag "right" (`--surface-sunken`, `--accent-text`). Every other row shows a small "as right" button (absolute right 6 / top 8, height 20, padding 0 6, 1px `--border`, radius 6, mono 500 10.5px; hover accent) — tooltip "Compare against this workflow, on the right".

---

## 1 · Edit

Center column unchanged from the current code (header with file/status/path, problems chip, Discard, Save…; disk-change banner; toolbar with counts and paths/descriptions pills; flow diagram; Append step; legend) with these changes:

- **Remove** the workstreams dropdown in the toolbar, the run banner and the Run tab. Edit has no workstream view.
- Diagram additions: an **Inputs** card above the first step (dashed `--border-strong`, radius 10, padding 8 10, kicker "INPUTS" mono 10.5 uppercase, chips `artifact` + "required" (`--accent-text`) / "optional" (`--text-faint`)); a **Hands off to** card after Append step with link buttons "examples/custom-example-small →" + "when …" (Plex 11.5 muted), which open that workflow. Legend gains "↳ child workflow".
- Gate chip for `workflow` gates: kind label "workflow" on `--surface-sunken` / `--accent-text`, extra "↳ {child slug}".
- A step is **selected** by clicking it (accent border, 3px `--ring`, gradient number box) — independent of whether the rail is open.

### Right rail
**Strip** (always visible, far right): width 68, padding 8 6, gap 2, `--surface`, 1px `--border` left. Buttons in **scope order: Library, Workflow, Step**, each 56px tall, radius 8, Lucide icon 18px (book-open, settings-2, a card icon) above a label (Plex 500 11px).
- Active: `--accent-soft` bg, `--accent-text`, 2px `--accent` bar at the strip's left edge (left -6px, top/bottom 10px).
- **Step is disabled** (opacity .5, cursor not-allowed, tooltip "Select a step in the diagram") until a step is selected. Library is disabled for read-only workflows.
- Dots (7px, top 9 / right 13, 2px surface ring): Step — red when the selected step has a problem; Workflow — accent when the working copy is dirty.
- Clicking the active button closes the panel. Tooltips "Open Library" / "Close Library (Esc)".

**Panel** (between diagram and strip), **closed by default**: width `clamp(360px, 32vw, 470px)`, `--surface`, 1px `--border` left. Header 52px: title (Space Grotesk 700 15px) + subtitle (mono 11.5 muted: step "3 · guardrails", Library "adds to 3 · guardrails" or "no step selected", Workflow the file name) + **"× Close"** button (28px, Plex 500 12.5, tooltip "Close panel (Esc)"). Esc closes the panel; a second Esc clears the step selection.

- **Library tab:** as today, plus entries grouped into collapsible level sections (Project / Personal / fuse-flow, header like the lane groups with count and root path), entries filed under a folder shown under a `folder/` label and indented 14px. Entry detail adds a box "Same id on other levels" listing the other levels (level pill, "in effect" in `--accent-text` or "hidden by Project" in oklch(0.55 0.13 60), folder path) — click opens that entry; and a line "template.md is a link to …" above the file view when the file is a link.
- **Workflow tab:** segmented control at the top **Form | YAML | Changes · N** (container `--surface-sunken`, radius 8, buttons 26px, mono 12px). *Form*: Name, Description, **Inputs · N** (read-only rows: artifact, required/optional, description), **Hands off to · N** (link rows), the line "inputs and hands_off_to: edit in YAML", File, Workstreams list (a row click goes to the Workstreams page with that workstream selected). *YAML*: the file. *Changes*: line diff against the original or the disk version. A read-only workflow shows only YAML. "Compare" on the disk-change banner opens Workflow → Changes.
- **Step tab:** four collapsible sections **Basics / Instruction / Inputs and outputs / Gates** (header padding 13px 0, chevron, Plex 600 13.5px, red 7px dot on a problem, closed summary mono 11.5 muted ellipsis). Only Instruction open by default; a section with a problem is forced open. (Matches `StepSectionView` in `Inspector.tsx`.)
  - Gate kind select includes **workflow**: fields *child* (default `{slug}-child`) and *returns* (comma-separated artifact ids) in a two-column grid, plus "Open {workflow} →". At most one workflow gate per step (the adder hides when one exists).
  - Agent gates get a **Review in effect** box (`--surface-subtle`, 1px `--border`, radius 8): either "{guide path} · gate guide; replaces the artifact review guides" or one row per artifact review guide "{id}/review.md · {level}", each with **Open**; or "none · no review guide; the gate text is the whole review". The guide field gets an **Open** button.
  - **Guide viewer:** opens over the panel (absolute inset 0): "← Back to {tab}", title (Space Grotesk 700 16px), path (mono 11.5 faint), file text in a `--surface-sunken` pre (mono 12px/1.65).

### Read-only workflow from another project
Opened from the Workstreams page: header status "read-only · {project}'s own workflow", no editing controls, Workflow tab shows YAML only.

---

## 2 · Compare

Lane on the left (see shell). Main column:

- **Picker bar** (`--surface`, 1px `--border` bottom, padding 10 20 12): grid `1fr auto 1fr`. Each side: kicker "LEFT"/"RIGHT" (mono 10.5 uppercase), a select styled as a 34px field showing "{Location} · {dir}{file}" with a chevron, and the file path below (mono 11 faint). Left = the global selection; choosing a left workflow changes the global selection. Middle: **"⇄ Swap"** button (34px, 1px `--border-strong`, Lucide arrow-left-right 15px).
- **Summary bar** (`--surface-subtle`, padding 10 20): count chips "N same · N changed · N only left · N only right · N moved" (24px pill, 17px marker circle with = ≠ − + ↕), then toggles **only differences** / **all instructions** (pill toggles), then the left workflow's status ("saved" / "modified · working copy") and **Save…**.
- **Rows** (max-width 1440, gap 8): grid `minmax(0,1fr) 40px minmax(0,1fr)`. Gutter: hairline across + 24px marker circle with the row status (tooltip). With *only differences*, runs of identical steps collapse into one dashed row "= 3 identical steps · id, id, id" (click shows them).

**Alignment:** longest common subsequence over step ids. Matched pairs are *same* or *changed*. An id only on one side is *only left* / *only right*. An id on both sides but outside the LCS is *moved* and appears twice, with an empty slot "moved to step N" / "moved from step N" on the other side.

**Card** (both sides): `--surface`, 1px border (status colour unless same), radius 12, padding 10 12 12. Number box 24px, title (Plex 600 14px, amber background if changed), id (mono 11 faint), "moved to N →" pill. Then phase (amber if changed), condition box (amber if changed), instruction **word diff** (left: removed words red + strike-through; right: added words green) — shown when it differs, or always with *all instructions*; consume chips and output chips (red/strike on the left side if missing on the right, green on the right if missing on the left, amber if the path differs; outputs show G T R or "no guide"); gate chips with a 1.5px outline in the same colours.

**Editing:** the left workflow is the editable working copy. Clicking a left card selects that step (outline + ring) and opens the **same right rail as Edit** (Library / Workflow / Step). The right side is read-only, with apply actions:
- *Changed* card: below a dashed rule, one line per difference — marker (+ − ≠), label ("title → …", "phase → …", "condition → agent: …", "instruction", "consumes x", "produces x", "x path → …", "gate owner: …", "gate …(settings)"), and **"← Apply"** (22px, 1px `--border`, `--accent-text`). Header button **"← Apply all"** when there are 2+ differences — makes the left step equal to the right one.
- *Only right*: **"← Add to left as step N"** inserts a copy at the matching position.
- *Only left*: the empty right slot shows **"← Apply · remove from left"**.
- *Moved*: **"← Move left step here"**.
Primary apply buttons: 24px, padding 0 9, 1px `--accent`, `--accent-soft`, `--accent-text`, Plex 600 11.5. Each apply is an edit in the working copy (toast "Applied to {id}: {label}").

---

## 3 · Present

The same diagram component as Edit, **read-only**, for the global selection. No Edit header or toolbar, no move/delete buttons, no insert seams, no Append step, no problem highlights; clicking a step does nothing. Above the diagram: workflow name (Space Grotesk 700 26px, -0.015em) and description (Plex 15px/1.5 muted, max 70ch). Top padding 36px.

- **Left drawer (Workflows):** collapsed to a **20px strip** (`--surface`, 1px `--border`) with an 18×28 arrow button and a vertical label "WORKFLOWS" (mono 500 10.5 uppercase .12em `--text-faint`, `writing-mode: vertical-rl`, rotated 180°). Hovering the strip slides the 240px lane in over the diagram (`translateX`, 180ms `--ease-out`, `--shadow-lg`); leaving closes it. The arrow pins it open (tooltip "Keep workflows open" / "Collapse workflows").
- **Right drawer (Show):** same pattern on the right with label "SHOW". Panel (240px, padding 16, gap 14): title "Show" + file name; picker **"Side by side with"** (34px select field; options "none" + all other workflows); checkboxes (16px box, `--accent` when on, white ✓; rows 32px, Plex 500 13px): **Phases, Descriptions, Conditions, Artifacts, Gates, Consume lines, Route-back lines** — all on by default; buttons **Show all** / **Steps only**.
- Toggles hide the element type in the diagram; the **legend shows only entries for visible types** (consumes ↔ Consume lines, route back ↔ Route-back lines, "~ updates · id? may produce · G T R" ↔ Artifacts, "↳ child workflow" ↔ Gates).
- **Second workflow:** when chosen, the scroll area becomes two columns (gap 28, side padding 12), the second separated by a 1px `--border` left rule, with its own title/description and the same diagram (incl. consume and route-back lines), following the same toggles. Default is one workflow.
- Esc un-pins both drawers.

---

## 4 · Workstreams

Lane on the left (filters by the global selection, or "All workstreams"). Right **rail 340px** (`--surface`, 1px `--border` left); detail in the middle (`--surface-subtle`).

**Rail**
- Header 52px: title = selected workflow file or "All workstreams" (Space Grotesk 700 15px), subtitle "N projects" (mono 11 muted); **"Add projects"** button (30px, Lucide folder-plus 15px, tooltip "Look for workstreams in a folder and the four folder levels below it").
- **Projects are collapsible dividers**, styled like the lane's location groups: chevron, name (mono 500 11 uppercase .12em), tag pill "this project" / "examples", count "N workstreams" or "x of y workstreams" when filtered, or "folder not found" in red; **Remove** text button (hand-added projects only; tooltip "Remove {name} from the list; its workstreams stay where they are"). Path as tooltip.
- Workstream rows under their project: grid `10px 1fr auto`, padding 7 10, radius 8; 9px state dot; slug (mono 500 12.5) + workflow file (mono 11 muted); right: state pill + "at {step} · {duration}" or "took {duration}" (mono 10.5 faint). Child workstreams follow their parent, indented 28px with "↳ ". Selected: 1px `--accent` + `--accent-soft`. Empty project: "no workstreams of {file}". No state filter chips.
- Selection defaults to the first workstream in the list.

**Detail** (max-width 880, padding 22 28 48, gap 18)
- Header: slug (Space Grotesk 700 24px) + state pill; right: segmented **Summary | Diagram** (container `--surface-sunken` radius 8; buttons 28px, padding 0 14, Plex 600 12.5).
- Meta line (mono 12 muted): workflow file · project · "started Oct 2 09:02 · running for 2d 5h".
- Links line: "child of step code-review of [export-to-pdf]", "started after [saved-filters]", "child workstream [..]", "followed by [..]" — link buttons (22px, mono 12, `--accent-text`) select that workstream.
- Read-only note for workflows of other projects.
- **Summary:** 4-column stat strip (at step · running for/took · waited for owner · sent back), Steps list (number, title, "1h 30m · owner 2h 23m · ×2 visits", state pill; current step has a 3px inset bar in its state colour), Events newest first (time · step · from → to pills · actor · detail).
- **Diagram:** state legend, then the workflow as read-only step cards with the workstream's state: phase dividers, 14px connector between cards, card border and 3px left bar in the state colour (not-started/skipped faded to .72, skipped/conditional dashed), condition box, consume/output chips, gate chips, "Xh working · owner Ym · ×N visits", "↩ sent back to {step}" (oklch(0.55 0.13 60)), state pill on the right.

**Add projects modal** (max 480, radius 12, padding 24): title, Folder input (placeholder "~/workspace"), line "Looks for fuse-flow workstreams in this folder and up to four folder levels below it.", error lines "No fuse-flow workstreams in this folder or the four folder levels below it." / "Found N projects there, all listed already.", Cancel / Add.

---

## State
- `page: 'edit' | 'compare' | 'present' | 'workstreams'`
- `currentWorkflowKey` (global), `selectedStepIndex | null`
- Edit rail: `railOpen`, `railTab: 'library' | 'workflow' | 'step'`, `workflowView: 'form' | 'yaml' | 'changes'`, `viewer` (guide file), section open map (persisted)
- Lane/library fold maps (persisted)
- Compare: `compareRightKey`, `onlyDifferences`, `allInstructions`
- Present: `show: { phases, descriptions, conditions, artifacts, gates, consumes, routes }`, `presentSecondKey | null`, `leftDrawerPinned/hover`, `rightDrawerPinned/hover`
- Workstreams: `allWorkstreams` (bool), `selectedWorkstream`, `summaryOrDiagram`, project fold map, projects list (existing API `api.projects/addProjects/removeProject`)
- Theme (existing)

No new server endpoints. Compare applies are ordinary `applyEdit` operations on the left working copy (`setStepField`, `setInstruction`, `setCondition`, `setConsumes`, output/gate add/remove/set, `insertStep`, `moveStep`, `deleteStep`).

## Design tokens
From `src/tokens/*.css` (On Coding). Additional semantic tints, as functions of hue *h*:

| | background | text | border |
|---|---|---|---|
| light | `oklch(0.95 0.045 h)` | `oklch(0.44 0.12 h)` | `oklch(0.72 0.14 h)` |
| dark | `oklch(0.33 0.06 h)` | `oklch(0.86 0.1 h)` | `oklch(0.62 0.13 h)` |

Hues: agent gate 160 · owner gate / waiting / changed 80 · blocked / only-left / removed 25 · completed / only-right / added 150. Check gate and in-progress use `--accent-soft`/`--accent-text`; script gate and workflow gate use `--surface-sunken` (text `--text-strong` / `--accent-text`). Route back `oklch(0.62 0.13 65)`; error `oklch(0.58 0.19 25)`.

Radii: controls 6–8, cards 12, pills 999. Motion: 120ms chevrons, 180ms drawers, `--ease-out`. Type: Space Grotesk (titles), IBM Plex Sans (UI/prose), JetBrains Mono (ids, meta, kickers uppercase .08–.12em).

## Assets
Icons are Lucide (the code already uses `lucide-react`): book-open, settings-2, file/card, x, moon, sun, arrow-left-right, sliders-horizontal, folder-plus, chevron-right, chevron-down. No images.

## Code map (fuse/komposer/src)
- `App.tsx` — add `page` and the top bar; hoist current workflow; route to the four pages; remove the runs select, `RunBanner` and run tab handling from Edit.
- `WorkflowList.tsx` — per-page meta/rows (All workstreams, Other projects, compare tags, "as right"); move brand + `ThemeToggle` to the top bar; no projects footer.
- `ProjectList.tsx` — becomes the Workstreams rail (projects as dividers with workstreams beneath).
- `Inspector.tsx` — strip + panel; tab order Library/Workflow/Step; YAML/Changes inside Workflow; Step disabled without selection; remove Run tab; review-in-effect, workflow gate fields, guide viewer.
- `Flow.tsx` — `readOnly` and `show` props for Present; reuse for the second workflow; inputs/hand-offs cards.
- New: `Compare.tsx` (alignment, word diff, apply actions), `Present.tsx` (drawers), `Workstreams.tsx` (rail, detail, Summary/Diagram).
- Rename every visible "run" to "workstream" (`runView.ts` labels, toasts, empty states).

## Files in this bundle
- `Workflow Editor v3.dc.html` — the prototype (template + logic in one file)
- `komposer-data.js`, `komposer-data-v3.js` — sample data (workflows from the repo, projects, workstreams incl. parent/child and send-backs, library entries)
- `support.js` — prototype runtime (not for production)
- `_ds/` — On Coding token CSS used by the prototype
