// v3 additions: projects, runs across projects, run links, workflow inputs / hand-offs,
// a workflow gate (child workstream), a read-only workflow from another project, library groups and links.
(function () {
  const D = window.KOMPOSER_DATA;
  if (D._v3) return; D._v3 = true;
  const wf = (file) => D.workflows.find((w) => w.file === file);
  const step = (w, id) => w.steps.find((s) => s.id === id);

  const large = wf('custom-example-large');
  large.inputs = [{ artifact: 'request', required: true, description: 'The request as the owner wrote it.' }];
  step(large, 'elicitation').consumes = ['request'];
  large.hands_off_to = [{ workflow: 'examples/custom-example-small', when: 'a follow-up fix is needed after release' }];
  step(large, 'code-review').gates.push({ kind: 'workflow', text: 'examples/custom-example-small', child: '{slug}-fixes', returns: ['code-review'], route_back_to: [], description: 'Fix the critical findings in a child workstream.' });
  const medium = wf('custom-example-medium');
  medium.inputs = [{ artifact: 'feature-request', required: false, description: 'A ticket or note describing the feature.' }];
  medium.hands_off_to = [{ workflow: 'examples/custom-example-large', when: 'the feature turns out to be several features' }];

  // A workflow that lives in another project; it opens only with its run, read-only.
  const mk = (id, title, instruction, o) => Object.assign(D.newStep(id), { title, instruction }, o);
  const billing = {
    loc: 'run', dir: '', file: 'billing-release', name: 'billing-release', description: 'Change, migration check and release for the billing service.',
    project: 'billing-service', path: '~/workspace/billing-service/.konductor/workflows/billing-release.yml', head: [], blank: false,
    steps: [
      mk('change', 'Change', 'Implement the change with tests; record the commands and results.', { arts: [{ mode: 'updates', artifact: 'code', path: '.', description: '' }], gates: [{ kind: 'check', text: 'default', route_back_to: [], description: '' }] }),
      mk('migration-check', 'Migration check', 'Dry-run the database migration against a copy of production.', { consumes: [], arts: [{ mode: 'produces', artifact: 'migration-report', path: '.konductor/{slug}/migration.md', description: '' }], gates: [{ kind: 'script', text: './scripts/migrate --dry-run', route_back_to: ['change'], description: '' }] }),
      mk('release', 'Release', 'Tag the release and write the release note.', { consumes: ['migration-report'], arts: [{ mode: 'produces', artifact: 'release-note', path: 'docs/releases/{slug}.md', description: '' }], gates: [{ kind: 'owner-action', text: 'approve the release', route_back_to: [], description: '' }] }),
    ],
  };
  D.workflows.push(billing);

  D.PROJECTS = [
    { name: 'semikonductor', path: '/home/thiemo/workspace/semikonductor', current: true },
    { name: 'billing-service', path: '/home/thiemo/workspace/billing-service' },
    { name: 'old-cli', path: '/home/thiemo/workspace/old-cli', missing: true },
    { name: 'example-runs', path: '/home/thiemo/workspace/semikonductor/fuse/komposer/example-runs', example: true },
  ];
  D.RUNS.forEach((r) => { r.project = 'semikonductor'; });

  const pad = (n) => String(n).padStart(2, '0');
  const t2m = (t) => { const [d, h] = t.split(' '); const [M, Dd] = d.split('-').map(Number); const [H, Mi] = h.split(':').map(Number); return ((M * 31 + Dd) * 24 + H) * 60 + Mi; };
  const m2t = (m) => { const Mi = m % 60, H = Math.floor(m / 60) % 24, days = Math.floor(m / 1440), M = Math.floor(days / 31), Dd = days % 31; return pad(M) + '-' + pad(Dd) + ' ' + pad(H) + ':' + pad(Mi); };
  // Each step: in progress, then completed `per` minutes later.
  const chain = (ids, start, per, ev = []) => { let m = t2m(start); ids.forEach((id) => { ev.push([m2t(m), id, 'not_started', 'in_progress', 'agent', '']); m += per; ev.push([m2t(m), id, 'in_progress', 'completed', 'agent', 'Recorded.']); m += 2; }); return { ev, t: m2t(m) }; };
  const K = (f) => 'fuse-flow:examples/' + f;
  const L = large.steps.map((s) => s.id);
  const NOW = '10-04 14:20';

  const csv = chain(['implementation', 'code-review'], '09-30 10:00', 30).ev;
  csv.push(['09-30 11:06', 'final-summary', 'not_started', 'in_progress', 'agent', ''], ['09-30 11:15', 'final-summary', 'in_progress', 'waiting', 'agent', 'Recorded sdlc-summary.'], ['09-30 13:02', 'final-summary', 'waiting', 'completed', 'owner', 'Approved.']);

  const retry = [
    ['10-03 09:00', 'implementation', 'not_started', 'in_progress', 'agent', ''],
    ['10-03 09:30', 'implementation', 'in_progress', 'in_progress', 'agent', 'check default: failed, 2 tests.'],
    ['10-03 09:58', 'implementation', 'in_progress', 'completed', 'agent', 'check default: passed.'],
    ['10-03 10:00', 'code-review', 'not_started', 'in_progress', 'agent', ''],
    ['10-03 10:40', 'code-review', 'in_progress', 'blocked', 'agent', 'The review found a race the change cannot fix alone.'],
  ];

  const filters = chain(['codebase-analysis', 'requirements'], '10-02 13:00', 45).ev;
  filters.push(['10-02 14:40', 'design', 'not_started', 'in_progress', 'agent', ''], ['10-02 15:30', 'design', 'in_progress', 'waiting', 'agent', 'Recorded design.']);

  const pdf = chain(L.slice(0, L.indexOf('code-review')), '10-03 08:00', 25).ev;
  pdf.push(['10-04 11:40', 'code-review', 'not_started', 'in_progress', 'agent', ''], ['10-04 12:05', 'code-review', 'in_progress', 'in_progress', 'agent', 'workflow gate: started child export-to-pdf-fixes.']);

  const fixes = [['10-04 12:06', 'implementation', 'not_started', 'in_progress', 'agent', 'Child of export-to-pdf, step code-review.']];

  const tw1 = chain(L.slice(0, L.indexOf('design-signoff')), '09-24 09:00', 40);
  const tw = tw1.ev;
  let m = t2m(tw1.t);
  tw.push([m2t(m), 'design-signoff', 'not_started', 'in_progress', 'agent', ''], [m2t(m += 20), 'design-signoff', 'in_progress', 'waiting', 'agent', 'Recorded design-signoff.'], [m2t(m += 90), 'design', 'completed', 'in_progress', 'owner', 'Sent back: the threat model misses tenant isolation.', 'design-signoff']);
  const tw2 = chain(['design', 'threat-model', 'design-review', 'design-signoff'].slice(0, 0), m2t(m), 30);
  tw.push([m2t(m += 50), 'design', 'in_progress', 'completed', 'agent', 'Recorded design.'], [m2t(m += 2), 'design-signoff', 'waiting', 'in_progress', 'agent', ''], [m2t(m += 20), 'design-signoff', 'in_progress', 'waiting', 'agent', 'Recorded design-signoff.'], [m2t(m += 60), 'design-signoff', 'waiting', 'completed', 'owner', 'Approved.']);
  chain(L.slice(L.indexOf('design-signoff') + 1), m2t(m + 5), 45, tw);

  const inv = chain(['change'], '10-04 09:00', 70).ev;
  inv.push(['10-04 10:15', 'migration-check', 'not_started', 'in_progress', 'agent', '']);

  D.RUNS.push(
    { id: 'fix-csv-quoting', wf: K('custom-example-small'), project: 'example-runs', now: NOW, events: csv },
    { id: 'retry-on-timeout', wf: K('custom-example-small'), project: 'example-runs', now: NOW, events: retry },
    { id: 'saved-filters', wf: K('custom-example-medium'), project: 'example-runs', now: NOW, events: filters },
    { id: 'export-to-pdf', wf: K('custom-example-large'), project: 'example-runs', now: NOW, after: 'saved-filters', events: pdf },
    { id: 'export-to-pdf-fixes', wf: K('custom-example-small'), project: 'example-runs', now: NOW, parent: { slug: 'export-to-pdf', step: 'code-review' }, events: fixes },
    { id: 'team-workspaces', wf: K('custom-example-large'), project: 'example-runs', now: NOW, events: tw },
    { id: 'invoice-rounding', wf: 'run:billing-release', project: 'billing-service', now: NOW, events: inv },
  );

  // Library: folders an entry is filed under, and files that are links.
  D.LIBX = {
    'threat-model@personal': { group: 'security' },
    'code-review@project': { group: 'review' },
    'design@project': { links: { 'template.md': '../../templates/adr.md' } },
  };
})();
